package testcases.Appsheet;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import supportLibraries.Browser;
import supportLibraries.ExecutionMode;
import supportLibraries.MainScript;
import supportLibraries.SeleniumTestParameters;
import supportLibraries.TestCase;

public class TC_01 extends TestCase {

	@Test(dataProvider = "TC_01")
	public void testRunner(ExecutionMode executionMode, Browser browser) throws Exception {
		SeleniumTestParameters testParameters = new SeleniumTestParameters(currentScenario, currentTestcase);
		testParameters.setCurrentTestDescription("Test Case - 01");
		testParameters.setExecutionMode(executionMode);
		testParameters.setBrowser(browser);

		MainScript driverScript = new MainScript(testParameters);
		driverScript.driveTestExecution();
	}

	@DataProvider(name = "TC_01", parallel = false)
	public Object[][] dataTC() {
		return new Object[][] {
				{ ExecutionMode.LOCAL, Browser.CHROME }, };
	}
}