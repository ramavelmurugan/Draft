package supportLibraries;

import org.openqa.selenium.Platform;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

/**
 * Abstract base class for all the test cases to be automated
 * 
 * @author Rama Velmurugan
 */
public abstract class TestCase {
	/**
	 * The current scenario
	 */
	protected String currentScenario;
	/**
	 * The current test case
	 */
	protected String currentTestcase;

	/**
	 * Function to do the required framework setup activities before executing
	 * each test case
	 */
	@BeforeMethod(alwaysRun=true)
	public void setUpTestRunner() {
		currentScenario = this.getClass().getPackage().getName().substring(10);
		currentTestcase = this.getClass().getSimpleName();

	}

}