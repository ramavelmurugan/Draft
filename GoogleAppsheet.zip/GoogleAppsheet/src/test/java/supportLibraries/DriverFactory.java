package supportLibraries;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * DriverFactory which will create respective driver Object
 * 
 * @author Rama Velmurugan
 */
public class DriverFactory {

	/*static Logger log = Logger.getLogger(DriverFactory.class);

	public static WebDriver createInstanceWebDriver(SeleniumTestParameters testParameters) {
		WebDriver driver = null;
		try {
			switch (testParameters.getExecutionMode()) {

			case LOCAL:
				driver = WebDriverFactory.getWebDriver(testParameters.getBrowser());
				break;

			default:
				throw new Exception("Unhandled Execution Mode!");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error(ex.getMessage());
		}
		return driver;
	}*/

}