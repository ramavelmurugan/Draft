package supportLibraries;

import org.openqa.selenium.WebDriver;



/**
 * Wrapper class for common framework objects, to be used across the entire test
 * case and dependent libraries
 * 
 * @author Rama Velmurugan
 */
public class ScriptHelper {

	private final DataTable dataTable;
	private Driver craftDriver;
	private SeleniumTestParameters testParameters;

	/**
	 * Constructor to initialize all the objects wrapped by the
	 * {@link ScriptHelper} class
	 * 
	 * @param dataTable
	 *            The {@link DataTable} object
	 * @param report
	 *            The {@link SeleniumReport} object
	 * @param driver
	 *            The {@link WebDriver} object
	 * @param driverUtil
	 *            The {@link WebDriverUtil} object
	 * @param testParameters
	 *            The {@link SeleniumTestParameters} object
	 */

	public ScriptHelper(DataTable dataTable,  Driver craftDriver,
			 SeleniumTestParameters testParameters) {
		this.dataTable = dataTable;
		this.craftDriver = craftDriver;
		this.testParameters = testParameters;
	}

	/**
	 * Function to get the {@link DataTable} object
	 * 
	 * @return The {@link DataTable} object
	 */
	public DataTable getDataTable() {
		return dataTable;
	}

	
	/**
	 * Function to get the {@link Driver} object
	 * 
	 * @return The {@link Driver} object
	 */
	public Driver getDriver() {
		return craftDriver;
	}

	/**
	 * Function to get the {@link SeleniumTestParameters} object
	 * 
	 * @return The {@link SeleniumTestParameters} object
	 */
	public SeleniumTestParameters getTestParameters() {
		return testParameters;
	}

}