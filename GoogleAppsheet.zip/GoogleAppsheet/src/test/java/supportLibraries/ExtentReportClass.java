package supportLibraries;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.*;

public class ExtentReportClass {
	
	public static ExtentTest test;
	public static ExtentReports report;

	private static String reportPathFolder = System.getProperty("user.dir") + System.getProperty("file.separator") + 
			"Extent Report Results" + System.getProperty("file.separator") + getTodayDateTime();

	private static String reportPathFile = "OLA_ExtentReportResults_" + "Run_" + getTodayDateTime();

	@BeforeClass
	public void startTest() {
		mkdirectory(reportPathFolder);
		report = new ExtentReports(reportPathFolder + System.getProperty("file.separator") + 
				reportPathFile + ".html");
	}

	@AfterClass
	public void endTest() {
		atEndTest();
	}

	private void atEndTest() {
		report.endTest(test);
		report.flush();
	}

	public static String capture(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File(reportPathFolder + System.getProperty("file.separator") + "Screenshots/" + 
				System.currentTimeMillis() + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	public static String getTodayDateTime() {
		DateFormat df = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
		Calendar calobj = Calendar.getInstance();

		return df.format(calobj.getTime());
	}

	public void mkdirectory(String reportPathFolder) {
		File theDir = new File(reportPathFolder);
		if (!theDir.exists()){
			theDir.mkdirs();
		}
	}
}