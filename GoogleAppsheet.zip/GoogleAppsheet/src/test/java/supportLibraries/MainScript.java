package supportLibraries;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.taskdefs.Definer.OnError;
import org.asynchttpclient.util.HttpConstants.Methods;
import org.openqa.selenium.WebDriver;

/**
 * Driver script class which encapsulates the core logic of the framework
 * 
 * @author Rama Velmurugan
 */
public class MainScript {
	private List<String> businessFlowData;
	private Date endTime,startTime;
	private int currentIteration, currentSubIteration;
	private String executionTime;
	private DataTable dataTable;
	private Driver driver;
	private ScriptHelper scriptHelper;
	private Properties properties;
	private String runTimeDatatablePath;
	private final SeleniumTestParameters testParameters;
	private final FrameworkParameters frameworkParameters = FrameworkParameters.getInstance();

	/**
	 * DriverScript constructor
	 * 
	 * @param testParameters
	 *            A {@link SeleniumTestParameters} object
	 */
	public MainScript(SeleniumTestParameters testParameters) {
		this.testParameters = testParameters;
	}


	/**
	 * Function to get the execution time for the test case
	 * 
	 * @return The test execution time
	 */
	public String getExecutionTime() {
		return executionTime;
	}

	/**
	 * Function to execute the given test case
	 * @throws Exception 
	 */
	public void driveTestExecution() throws Exception {
		startUp();
		initializeWebDriver();
		initializeDatatable();
		execute();
		wrapUp();
	}

	private void execute() throws Exception {
		initializeTestScript();
		executeTestIterations();
	}

	private void startUp() {
		startTime = Util.getCurrentTime();
		properties = Settings.getInstance();
		setDefaultTestParameters();
	}

	private void setDefaultTestParameters() {
		if (testParameters.getExecutionMode() == null) {
			testParameters.setExecutionMode(ExecutionMode.valueOf(properties.getProperty("DefaultExecutionMode")));
		}

		if (testParameters.getBrowser() == null) {
			testParameters.setBrowser(Browser.valueOf(properties.getProperty("DefaultBrowser")));
		}
	}

	private int getNumberOfIterations() throws Exception {
		String datatablePath = frameworkParameters.getRelativePath() + Util.getFileSeparator() + "src"
				+ Util.getFileSeparator() + "test" + Util.getFileSeparator() + "resources" + Util.getFileSeparator()
				+ "Datatables";
		ExcelDataAccessforxlsx testDataAccess = new ExcelDataAccessforxlsx(datatablePath, testParameters.getCurrentScenario());
		testDataAccess.setDatasheetName(properties.getProperty("DefaultDataSheet"));

		int startRowNum = testDataAccess.getRowNum(testParameters.getCurrentTestcase(), 0);
		int nTestcaseRows = testDataAccess.getRowCount(testParameters.getCurrentTestcase(), 0, startRowNum);
		int nSubIterations = testDataAccess.getRowCount("1", 1, startRowNum); // Assumption:
		// Every
		// test
		// case
		// will
		// have
		// at
		// least
		// one
		// iteration
		return nTestcaseRows / nSubIterations;

	}

	@SuppressWarnings("rawtypes")
	private void initializeWebDriver() throws Exception {

		//driver =DriverFactory.createInstanceWebDriver(testParameters);
		switch (testParameters.getExecutionMode()) {

		case LOCAL:
			WebDriver webDriver = WebDriverFactory.getWebDriver(testParameters.getBrowser());
			driver = new Driver(webDriver);
			driver.setTestParameters(testParameters);
			//Launch URL
			driver.get(properties.getProperty("ApplicationUrl"));
			WaitPageLoad();
			break;

		default:
			throw new Exception("Unhandled Execution Mode!");
		}
		implicitWaitForDriver();
	}

	private void implicitWaitForDriver() {
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}

	private void WaitPageLoad() {
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	private synchronized void initializeDatatable() throws Exception {
		String datatablePath = frameworkParameters.getRelativePath() + Util.getFileSeparator() + "src"
				+ Util.getFileSeparator() + "test" + Util.getFileSeparator() + "resources" + Util.getFileSeparator()
				+ "Datatables";

		
		runTimeDatatablePath="";
		File runTimeDatatable = new File(
				runTimeDatatablePath +testParameters.getCurrentScenario() + ".xlsx");
		if (!runTimeDatatable.exists()) {
			File datatable = new File(
					datatablePath + Util.getFileSeparator() + testParameters.getCurrentScenario() + ".xlsx");
			try {
				FileUtils.copyFile(datatable, runTimeDatatable);
			} catch (IOException e) {
				e.printStackTrace();
				throw new Exception(
						"Error in creating run-time datatable: Copying the datatable failed...");
			}
		}	
		dataTable = new DataTable(runTimeDatatablePath, testParameters.getCurrentScenario());	
	}

	private void initializeTestScript() throws Exception {
		scriptHelper = new ScriptHelper(dataTable,driver, testParameters);
		initializeBusinessFlow();
	}

	private void initializeBusinessFlow() throws Exception {
		ExcelDataAccessforxlsx businessFlowAccess = new ExcelDataAccessforxlsx(
				System.getProperty("user.dir") + Util.getFileSeparator() + "src" + Util.getFileSeparator()
				+ "test" + Util.getFileSeparator() + "resources" + Util.getFileSeparator() + "Datatables",
				testParameters.getCurrentScenario());
		businessFlowAccess.setDatasheetName("Business_Flow");

		int rowNum = businessFlowAccess.getRowNum(testParameters.getCurrentTestcase(), 0);
		if (rowNum == -1) {
			throw new Exception("The test case \"" + testParameters.getCurrentTestcase()
			+ "\" is not found in the Business Flow sheet!");
		}

		String dataValue;
		businessFlowData = new ArrayList<String>();
		int currentColumnNum = 1;
		while (true) {
			dataValue = businessFlowAccess.getValue(rowNum, currentColumnNum);
			if ("".equals(dataValue)) {
				break;
			}
			businessFlowData.add(dataValue);
			currentColumnNum++;
		}

		if (businessFlowData.isEmpty()) {
			throw new Exception(
					"No business flow found against the test case \"" + testParameters.getCurrentTestcase() + "\"");
		}
	}

	private void executeTestIterations() {
		while (currentIteration <= testParameters.getEndIteration()) {

			// Evaluate each test iteration for any errors
			try {
				executeTestcase(businessFlowData);
			} catch (Exception fx) {

			}
			currentIteration++;
		}
	}

	private void executeTestcase(List<String> businessFlowData)
			throws Exception {
		Map<String, Integer> keywordDirectory = new HashMap<String, Integer>();

		for (int currentKeywordNum = 0; currentKeywordNum < businessFlowData.size(); currentKeywordNum++) {
			String[] currentFlowData = businessFlowData.get(currentKeywordNum).split(",");
			String currentKeyword = currentFlowData[0];

			int nKeywordIterations;
			if (currentFlowData.length > 1) {
				nKeywordIterations = Integer.parseInt(currentFlowData[1]);
			} else {
				nKeywordIterations = 1;
			}

			for (int currentKeywordIteration = 0; currentKeywordIteration < nKeywordIterations; currentKeywordIteration++) {
				if (keywordDirectory.containsKey(currentKeyword) && nKeywordIterations != 1) {
					keywordDirectory.put(currentKeyword, keywordDirectory.get(currentKeyword) + 1);
				} else {
					keywordDirectory.put(currentKeyword, 1);
				}
				currentSubIteration = keywordDirectory.get(currentKeyword);

				dataTable.setCurrentRow(testParameters.getCurrentTestcase(), currentIteration, currentSubIteration);

				invokeBusinessComponent(currentKeyword);
			}
		}
	}

	private void invokeBusinessComponent(String currentKeyword)
			throws Exception {
		Boolean isMethodFound = false;
		final String CLASS_FILE_EXTENSION = ".class";
		File[] packageDirectories = {
				new File(frameworkParameters.getRelativePath() + Util.getFileSeparator() + "target"
						+ Util.getFileSeparator() + "test-classes" + Util.getFileSeparator() + "businessComponents")};
		for (File packageDirectory : packageDirectories) {
			File[] packageFiles = packageDirectory.listFiles();
			String packageName = packageDirectory.getName();
			//findClasses(packageDirectory,packageName);
			for (int i = 0; i < packageFiles.length; i++) {
				File packageFile = packageFiles[i];
				String fileName = packageFile.getName();

				// We only want the .class files
				if (fileName.endsWith(CLASS_FILE_EXTENSION)) {
					// Remove the .class extension to get the class name
					String className = fileName.substring(0, fileName.length() - CLASS_FILE_EXTENSION.length());

					Class<?> reusableComponents = Class.forName(packageName+"."+className);
					Method executeComponent;

					try {
						executeComponent = reusableComponents.getMethod(currentKeyword, (Class<?>[]) null);
					} catch (NoSuchMethodException ex) {
						// If the method is not found in this class, search the
						// next class
						continue;
					}

					isMethodFound = true;

					Constructor<?> ctor = reusableComponents.getDeclaredConstructors()[0];
					Object businessComponent = ctor.newInstance(scriptHelper);

				executeComponent.invoke(businessComponent, (Object[]) null);

					break;
				}
			}
		}

		if (!isMethodFound) {
			throw new Exception("Keyword " + currentKeyword + " not found within any class "
					+ "inside the businesscomponents package");
		}
	}

	private void wrapUp() {
		endTime = Util.getCurrentTime();
	}
	
}

