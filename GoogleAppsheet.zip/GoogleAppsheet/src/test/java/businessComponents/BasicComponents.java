package businessComponents;


public class BasicComponents {

	public void Execution(){
		System.out.println("Appsheet Execution!!");
	}
	public void Browser(){
		System.out.println("Close Browser!!");
	}

}
