package businessComponents;
import java.lang.Package;

import libraries.*;
import supportLibraries.ReusableLibrary;
import supportLibraries.ScriptHelper;

public class AppsheetComponents extends ReusableLibrary{
	
	public AppsheetComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	Login login = new Login(scriptHelper);
	Incident incident = new Incident(scriptHelper);

	public void Appsheet_Execution() throws Exception{
		System.out.println("Appsheet Execution begins!!");	
		
		login.logintoapplication();
		
		String sheetname="TestData";
		if (dataTable.getData(sheetname,"Create New Incident").equalsIgnoreCase("Yes")){
			incident.create_new_incident();
		}
	}
	
	public void Close_Browser(){
		driver.quit();
		System.out.println("Closed the Browser!!");
	}

}
