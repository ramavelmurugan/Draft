package libraries;

import supportLibraries.ReusableLibrary;
import supportLibraries.ScriptHelper;

public class Incident extends ReusableLibrary {

	public Incident(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	public void create_new_incident() {
		
		
	}

}
