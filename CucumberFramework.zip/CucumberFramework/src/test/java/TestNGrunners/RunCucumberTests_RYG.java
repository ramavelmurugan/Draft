package TestNGrunners;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.*;
import org.testng.annotations.*;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.*;
import supportLibraries.*;

//@ExtendedCucumberOptions(

		//jsonReport = "target/cucumber-report/Smoke/cucumber.json", jsonUsageReport = "target/cucumber-report/Smoke/cucumber-usage.json", outputFolder = "target/cucumber-report/E2E", detailedReport = true, detailedAggregatedReport = true, overviewReport = true, usageReport = true)

/**
 * Please notice that stepDefinations.CukeHooks class is in
 * the same package as the steps definitions. It has two methods that are
 * executed before or after scenario. I'm using it to delete cookies and take a
 * screenshot if scenario fails.
 */
@CucumberOptions(
		features = "src/test/resources/features/RYG_rules.feature",
		glue = {"stepDefinitions"},
		tags = {"@E2E"}, monochrome = true, 
		plugin ={"pretty", "html:target/cucumber-report/E2E"})

public class RunCucumberTests_RYG {
	private  TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun=true)
	public void setUpClass() {
		testNGCucumberRunner=new TestNGCucumberRunner(this.getClass());
	}

	@Test(dataProvider="features")
	public void feature(CucumberFeatureWrapper cucumberfeature) {
		testNGCucumberRunner.runCucumber(cucumberfeature.getCucumberFeature());
	}

	@DataProvider 
	public Object [][] features(){
	    if(testNGCucumberRunner == null){
	        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	    }
		return testNGCucumberRunner.provideFeatures();
	}
	
	@AfterTest
	private void test() {
		copyReportsFolder();
		testNGCucumberRunner.finish();
	}

	private void copyReportsFolder() {

		String timeStampResultPath = TimeStamp.getInstance();
		File sourceCucumber = new File(Util.getTargetPath());
		File destCucumber = new File(timeStampResultPath);
		try {
			FileUtils.copyDirectory(sourceCucumber, destCucumber);
			try {
				FileUtils.cleanDirectory(sourceCucumber);
			} catch (Exception e) {

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		TimeStamp.reportPathWithTimeStamp = null;
	}
}