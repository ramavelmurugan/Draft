package pageObjects;

import org.openqa.selenium.By;

public class SummaryStatus {
	
	public static final By summarystatus =  By.xpath("//*[contains(text(),'Summary Status')]");
		
}
