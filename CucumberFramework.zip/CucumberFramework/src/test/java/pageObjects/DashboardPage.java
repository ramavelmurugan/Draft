package pageObjects;

import org.openqa.selenium.By;

public class DashboardPage {

	public static final By dashboard=By.xpath("//a[text()=' App Engine Dashboard']");
	public static final By percentage=By.xpath("//div[@ng-show='c.data.percent']");
	public static final By red_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrRed']/..");
	public static final By yellow_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrYellow']/..");
	public static final By green_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrGreen']/..");

	public static final By add_release=By.xpath("//a[contains(text(),'Add a new release')]/..");
	public static final By release_name=By.xpath("//input[@id='sp_formfield_short_description']");
	public static final By description=By.xpath("//textarea[@id='sp_formfield_description']");
	public static final By start_date=By.xpath("//input[@id='sp_formfield_start_date']");
	public static final By end_date=By.xpath("//input[@id='sp_formfield_end_date']");
	public static final By ga_date=By.xpath("//input[@id='sp_formfield_u_ga_date']");
	public static final By submit=By.xpath("//button[@id='submit-btn']");

	public static final By releasetype_dropdown = By.xpath("//span[@id='select2-chosen-1']/..");
    public static final By releaseSearchInputBox = By.xpath("//input[@id='s2id_autogen1_search']");
	public static final By dialogBoxImpersonateUser = By.xpath("//h4[contains(text(),'Impersonate User')]");
	public static String releasetype,new_release_name,page_name,product_or_workstream;
	public static void setReleaseType(String releasetype) {
		releasetype="//div[text()='"+releasetype+"']/..";
	}
	public static void setRelease(String name) {
		new_release_name="//h5[text()='"+name+"']";
	}
	public static void setPage(String name) {
		page_name="//a[text()='"+name+"']";
	}
	public static void setProduct_or_Workstream(String name) {
		product_or_workstream="//h5[contains(text(),'"+name+"')]/..";	
	}
			
}
