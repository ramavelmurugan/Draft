package pageObjects;

import org.openqa.selenium.By;

public class DashboardPage {

	public static final By dashboard=By.xpath("//a[contains(text(),'Dashboard')]");
	public static final By percentage=By.xpath("//div[@ng-show='c.data.percent']");
	public static final By red_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrRed']/..");
	public static final By yellow_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrYellow']/..");
	public static final By green_dashboardcount=By.xpath("//div[@class='custLegends']//i[@class='fa fa-square clrGreen']/..");

	public static final By add_release=By.xpath("//a[contains(text(),'Add a new release')]/..");
	public static final By release_name=By.xpath("//input[@id='sp_formfield_short_description']");
	public static final By description=By.xpath("//textarea[@id='sp_formfield_description']");
	public static final By start_date=By.xpath("//input[@id='sp_formfield_start_date']");
	public static final By end_date=By.xpath("//input[@id='sp_formfield_end_date']");
	public static final By ga_date=By.xpath("//input[@id='sp_formfield_u_ga_date']");
	public static final By submit=By.xpath("//button[@id='submit-btn']");

	public static final By releasetype_dropdown = By.xpath("//span[@id='select2-chosen-1']/..");
    public static final By releaseSearchInputBox = By.xpath("//input[@id='s2id_autogen1_search']");
	public static final By dialogBoxImpersonateUser = By.xpath("//h4[contains(text(),'Impersonate User')]");
	public static String releasetype,new_release_name,page_name,product_or_workstream,product_tile,product_tile_color,dashboard_bom_cat_values,dashboard_arrow;
	
	public static void setReleaseType(String releasetype) {
		releasetype="//div[text()='"+releasetype+"']/..";
	}
	public static void setRelease(String name) {
		new_release_name="//h5[text()='"+name+"']";
	}
	public static void setPage(String name) {
		page_name="//a[contains(text(),'"+name+"')]";
	}
	public static void setProduct_or_Workstream(String name) {
		product_or_workstream="//h5[contains(text(),'"+name+"')]/..";	
	}
	
	public static void setProduct_tile(String Product) {
		product_tile="//div[@sn-atf-area='Summary in Dashboard']//div[contains(text(),'"+Product+"')]";
		dashboard_bom_cat_values="(//div[@sn-atf-area='Summary in Dashboard']//div[contains(text(),'"+Product+"')]/..//div[@class='bulletBox ng-scope redClr'])";
		dashboard_arrow="//div[@sn-atf-area='Summary in Dashboard']//div[contains(text(),'"+Product+"')]/..//div[@class='bulletBox ng-scope redClr']/../../../..//a";

	}
	public static void setProduct_tile_color(String Product,String color) {
		product_tile_color="//div[@sn-atf-area='Summary in Dashboard']//div[contains(text(),'"+Product+"') and @class='"+color+"']";
	}
	
	public static final By upcoming_milestones = By.xpath("//div[contains(text(),' Upcoming Milestones')]/a");
	public static String GTM_milestones = "(//div[@ng-repeat='ms in data.GTMmilestones'])";
	public static String GTM_milestone_activities = "(//div[@ng-repeat='child in data.milestones[c.currentMS].childs'])";
	public static final By state_dropdown=By.xpath("//label[text()='State']/../following-sibling::div//a");
	
	public static String state_value;
	public static void setDependent_BOM_Value(String value) {
		state_value="//*[@id='select2-results-6']//div[text()='"+value+"']";	
	}
	public static final By milestonesubmit=By.xpath("(//button[text()='Submit'])[1]");
	
	
}
