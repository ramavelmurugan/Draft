package testReporting;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class testingPurpose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// getting current date and time using Date class
		System.getProperty("file.separator");

		System.out.println(System.getProperty("file.separator"));
		
		String reportPathFolder = System.getProperty("user.dir") + System.getProperty("file.separator") + 
				"ExtentReportResults" + System.getProperty("file.separator") + getTodayDateTime() + System.getProperty("file.separator");
		
		System.out.println(reportPathFolder);
		
		String reportPathFile = "OLA_ExtentReportResults_" + getTodayDateTime();
		
		System.out.println(reportPathFolder + reportPathFile + ".html");
	}
	
	public static String getTodayDateTime() {
		// getting current date and time using Date class
		DateFormat df = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
		Calendar calobj = Calendar.getInstance();

		return df.format(calobj.getTime());
	}

	public static String capture(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("src/../BStackImages/" + System.currentTimeMillis()
		+ ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}
}
