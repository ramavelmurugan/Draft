package testReporting;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.apache.commons.io.FileUtils;

import org.openqa.selenium.*;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.*;

public class ExtentReport {

	static WebDriver driver;
	static String sen ="";

	protected static ExtentTest test;
	protected static ExtentReports report;
	
	private static String reportPathFolder = System.getProperty("user.dir") + System.getProperty("file.separator") + 
			"ExtentReportResults" + System.getProperty("file.separator") + getTodayDateTime();
	
	private static String reportPathFile = "OLA_ExtentReportResults_" + getTodayDateTime();

	@BeforeClass
	public static void startTest()
	{
		mkdirectory(reportPathFolder);

		report = new ExtentReports(reportPathFolder + System.getProperty("file.separator") + reportPathFile + ".html");

		test = report.startTest("Automation Testing for OLA");
	}

	//test.log(LogStatus.FAIL,test.addScreenCapture(capture(driver))+ "Test Failed");
	public static String capture(WebDriver driver) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File(reportPathFolder + System.getProperty("file.separator") + "BStackImages/" + System.currentTimeMillis()
		+ ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	public static String getTodayDateTime() 
	{
		DateFormat df = new SimpleDateFormat("dd_MMM_yyyy_HH_mm_ss");
		Calendar calobj = Calendar.getInstance();

		return df.format(calobj.getTime());
	}

	public static void mkdirectory(String reportPathFolder) {
		File theDir = new File(reportPathFolder);
		if (!theDir.exists()){
			theDir.mkdirs();
		}
	}

	/*public static String read(Scenario scenario) {

	    String featureName = "Feature ";
	    String rawFeatureName = (scenario).getName().split(";")[0].replace("-"," ");
	    featureName = featureName + rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);

	    return featureName;
	}*/

	/*private void shouldReturnScenarioTest() {
		Scenario actualScenario = Scenario.getScenario();
		assertEquals("My scenario", actualScenario.getName());
	}*/


	public static void screenShot() throws IOException, InterruptedException {

		String path = "C:\\Users\\pavan.balireddy\\Documents\\Maven project\\Seleniumtesting\\src\\main\\java\\"+sen+".png";
		File s = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(s, new File(path));
	}

	@AfterClass
	public static void endTest()
	{
		report.endTest(test);
		report.flush();
		System.out.println("END");
	}
}