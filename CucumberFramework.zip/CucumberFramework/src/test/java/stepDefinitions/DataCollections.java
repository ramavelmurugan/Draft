package stepDefinitions;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import dataCollections.*;

import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;

import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

public class DataCollections {

	private static Logger log = Logger.getLogger(DataCollections.class);
	static WebDriver driver = DriverManager.getWebDriver();

	public static BOMDetailsGTM_AllWS getSourceBOMDetailsGTM_AllWS() {
		
		BOMDetailsGTM_AllWS gtmAllWorkstream = null;
		
		/**
		 * Initialize the ArrayList
		 */
		ArrayList<String> getSourceWorkstream = new ArrayList<String>();
		ArrayList<String> getSourceBOMCategory = new ArrayList<String>();
		ArrayList<String> getSourceBOMName = new ArrayList<String>();
		ArrayList<String> getSourceAssignedto = new ArrayList<String>();
		ArrayList<String> getSourceState = new ArrayList<String>();
		ArrayList<String> getSourceStatus = new ArrayList<String>();
		ArrayList<String> getSourceDueDate = new ArrayList<String>();
		ArrayList<String> getSourcePartner = new ArrayList<String>();

		
		try {

			ReusableMethods.click(DetailedViewPage.filterIcon);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterComplete);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterOpen);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterWorkInProgress);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterNotRequired);
			ReusableMethods.click(DetailedViewPage.filterapply);

			int pageCount = driver.findElements(LoginPage.pageCount).size();
			 
			for (int pageNum=2; pageNum<=pageCount-1; pageNum++) {

				LoginPage.setPageNavigate(pageNum);				
				ReusableMethods.click(LoginPage.pageNavigate);
				
				//Column Header Checkpoint

				int tableSize = driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]"
						+ "/table/tbody/tr")).size();

				for (int i = 1; i<=tableSize; i++) {
					
					getSourceWorkstream.add(ReusableMethods.getText(By.xpath("((//th[contains(@ng-click,"
							+ "'workstream')])[1]/ancestor::thead/following-sibling::tbody"
							+ "//td[contains(@ng-if,'Allws')])[" + i + "]")));
					
					getSourceBOMCategory.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[7]")));
					
					getSourceBOMName.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[8]")));
					
					getSourceAssignedto.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[9]")));
					
					getSourceState.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[10]")));
					
					getSourceStatus.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[11]")));
					
					getSourceDueDate.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[12]")));
					
					getSourcePartner.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[13]")));
				}
			}

		} catch (Exception e) {
			log.error(e);
		}
		
		gtmAllWorkstream = new BOMDetailsGTM_AllWS(getSourceWorkstream, getSourceBOMCategory, getSourceBOMName, 
				getSourceAssignedto, getSourceState, getSourceStatus, getSourceDueDate, getSourcePartner);
		
		return gtmAllWorkstream;
	}

	public static BOMDetailsGTM_OneWS getSourceBOMDetailsGTM_OneWS() {
		
		BOMDetailsGTM_OneWS gtmOneWorkstream = null;
		
		/**
		 * Initialize the ArrayList
		 */
		ArrayList<String> getSourceWorkstream = new ArrayList<String>();
		ArrayList<String> getSourceBOMCategory = new ArrayList<String>();
		ArrayList<String> getSourceBOMName = new ArrayList<String>();
		ArrayList<String> getSourceAssignedto = new ArrayList<String>();
		ArrayList<String> getSourceState = new ArrayList<String>();
		ArrayList<String> getSourceStatus = new ArrayList<String>();
		ArrayList<String> getSourceDueDate = new ArrayList<String>();
		ArrayList<String> getSourcePartner = new ArrayList<String>();

		
		try {

			ReusableMethods.click(DetailedViewPage.filterIcon);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterComplete);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterOpen);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterWorkInProgress);
			ReusableMethods.selectCheckbox(DetailedViewPage.filterNotRequired);
			ReusableMethods.click(DetailedViewPage.filterapply);

			int pageCount = driver.findElements(LoginPage.pageCount).size();
			
			for (int pageNum=2; pageNum<=pageCount-1; pageNum++) {

				LoginPage.setPageNavigate(pageNum);				
				ReusableMethods.click(LoginPage.pageNavigate);
				
				//Column Header Checkpoint

				int tableSize = driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]"
						+ "/table/tbody/tr")).size();

				for (int i = 1; i<=tableSize; i++) {
					
					getSourceWorkstream.add(ReusableMethods.getText(By.xpath("((//th[contains(@ng-click,"
							+ "'workstream')])[1]/ancestor::thead/following-sibling::tbody"
							+ "//td[contains(@ng-if,'Allws')])[" + i + "]")));
					
					getSourceBOMCategory.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[7]")));
					
					getSourceBOMName.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[8]")));
					
					getSourceAssignedto.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[9]")));
					
					getSourceState.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[10]")));
					
					getSourceStatus.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[11]")));
					
					getSourceDueDate.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[12]")));
					
					getSourcePartner.add(ReusableMethods.getText(By.xpath("//*[@id='jsListView']/"
							+ "div[2]/div/div/div[4]/table/tbody/tr[" + i + "]/td[13]")));
				}
			}

		} catch (Exception e) {
			log.error(e);
		}
		
		gtmOneWorkstream = new BOMDetailsGTM_OneWS(getSourceWorkstream, getSourceBOMCategory, getSourceBOMName, 
				getSourceAssignedto, getSourceState, getSourceStatus, getSourceDueDate, getSourcePartner);
		
		return gtmOneWorkstream;
	}

	
}