package TestNGrunners;

import org.testng.annotations.*;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.*;
import supportLibraries.*;

/**
 * Please notice that stepDefinations.CukeHooks class is in
 * the same package as the steps definitions. It has two methods that are
 * executed before or after scenario. I'm using it to delete cookies and take a
 * screenshot if scenario fails.
 */
@CucumberOptions(
		features = "src/test/resources/features/OLA_E2E.feature",
		glue = {"stepDefinitions"},
		tags = {"@E2E"}, monochrome = true)

public class RunCucumberTests_E2E extends ExtentReportClass {
	private  TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun=true)
	public void setUpClass() {
		testNGCucumberRunner=new TestNGCucumberRunner(this.getClass());
	}

	@Test(dataProvider="features")
	public void feature(CucumberFeatureWrapper cucumberfeature) {
		testNGCucumberRunner.runCucumber(cucumberfeature.getCucumberFeature());
	}

	@DataProvider 
	public Object [][] features(){
	    if(testNGCucumberRunner == null){
	        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	    }
		return testNGCucumberRunner.provideFeatures();
	}
	
	@AfterTest
	private void test() {
		testNGCucumberRunner.finish();
	}
}