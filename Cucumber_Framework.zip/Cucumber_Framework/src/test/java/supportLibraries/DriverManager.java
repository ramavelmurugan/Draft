package supportLibraries;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * A generic WebDriver manager, which handles multiple instances of WebDriver.
 * 
 * @author Venkatesh Jayam
 */
public class DriverManager {

	/**
	 * Used for Multithreading of WebDriver Object
	 */
	private static ThreadLocal<WebDriver> webDriver = new ThreadLocal<WebDriver>();
	private static ThreadLocal<SeleniumTestParameters> testParameters = new ThreadLocal<SeleniumTestParameters>();

	static Logger log;

	static {
		log = Logger.getLogger(DriverManager.class);
	}

	// WebDriver Object Creation
	public static WebDriver getWebDriver() {
		if (webDriver.get() == null) {
			// this is need when running tests from IDE
			log.info("Thread has no WebDriver, creating new one");
			setWebDriver(DriverFactory.createInstanceWebDriver(null));
		}
		log.debug("Getting instance of remote driver" + webDriver.get().getClass());
		return webDriver.get();
	}

	@SuppressWarnings("deprecation")
	public static void setWebDriver(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		DriverManager.webDriver.set(driver);
	}
	
	public static void setTestParameters(SeleniumTestParameters testParameters) {
		DriverManager.testParameters.set(testParameters);
	}

	public static SeleniumTestParameters getTestParameters() {
		return testParameters.get();
	}
}