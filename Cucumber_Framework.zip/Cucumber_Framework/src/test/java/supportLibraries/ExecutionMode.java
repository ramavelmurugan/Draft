package supportLibraries;

/**
 * Enumeration to represent the mode of execution
 * 
 * @author Venkatesh Jayam
 */
public enum ExecutionMode {
	LOCAL("local");

	private String value;

	ExecutionMode(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}