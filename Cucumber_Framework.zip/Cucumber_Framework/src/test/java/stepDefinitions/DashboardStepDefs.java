package stepDefinitions;

import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;

public class DashboardStepDefs extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(DashboardStepDefs.class);
	}

	public static void select_tile_in_dashboard(String product, String workstream) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			String percentage=ReusableMethods.getText(DashboardPage.percentage).split("%")[0].trim();
			String redValue=ReusableMethods.getText(DashboardPage.red_dashboardcount).split("-")[1].trim();
			String greenValue=ReusableMethods.getText(DashboardPage.green_dashboardcount).split("-")[1].trim();
			String yellowValue=ReusableMethods.getText(DashboardPage.yellow_dashboardcount).split("-")[1].trim();
			double total=Integer.parseInt(redValue)+Integer.parseInt(greenValue)+Integer.parseInt(yellowValue);
			double actualPercentage=(Integer.parseInt(greenValue)*100)/total;

			if(ReusableMethods.two_decimal_places(actualPercentage).contains(percentage)) {
				test.log(LogStatus.PASS, "Actual Percentage = " + percentage + " Calculated Percentage = " +
						ReusableMethods.two_decimal_places(actualPercentage), 
						test.addScreenCapture(capture(driver)));
			} else {
				test.log(LogStatus.FAIL, "Actual Percentage = " + percentage + " Calculated Percentage = " +
						ReusableMethods.two_decimal_places(actualPercentage), 
						test.addScreenCapture(capture(driver)));
			}

			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
			DashboardPage.setProduct_tile(workstream);
			ReusableMethods.click(DashboardPage.product_tile);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Actual Percentage = ERROR Calculated Percentage = ERROR " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	public static void select_tile_in_dashboard_FL(String product, String workstream) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
			DashboardPage.setProduct_tile(product);
			ReusableMethods.click(DashboardPage.product_tile);
			test.log(LogStatus.PASS, "User successfully selected the product tiles, product name is " + product, 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			test.log(LogStatus.ERROR, e.getLocalizedMessage(), test.addScreenCapture(capture(driver)));
		}
	}

}