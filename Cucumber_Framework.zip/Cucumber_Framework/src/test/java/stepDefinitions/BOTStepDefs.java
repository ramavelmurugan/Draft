package stepDefinitions;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import pageObjects.AssignedToMePage;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.ScoreCardPage;
import pageObjects.ScorecardStatusPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;
import cucumber.api.DataTable;

public class BOTStepDefs extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(BOTStepDefs.class);
	}
	private static HashMap<String,String> workstream_data=new HashMap<String,String>();

	
	public static void add_document(DataTable Documentdata) throws InterruptedException, IOException {

		ReusableMethods.click(DashboardPage.dashboard);
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.add_document);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.enterData(DetailedViewPage.document_name,documentdata1.get("DocumentName"));
			ReusableMethods.enterData(DetailedViewPage.document_link,documentdata1.get("DocumentLinks"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			/*reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			reusableMethods.waitUntilElementEnabled(DetailedViewPage.added_message);
			reusableMethods.waitForLoad();		
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			reusableMethods.softAssertverification(message,"The Document Link has been added.");
			reusableMethods.click(DetailedViewPage.close_add_document_message); */
		}
	}

	public static void remove_document(DataTable Documentdata) throws InterruptedException, IOException {
		List<Map<String, String>> documentdata =Documentdata.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = documentdata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = documentdata.get(anchor);
			DetailedViewPage.set_document(documentdata1.get("DocumentName"));
			ReusableMethods.click(DetailedViewPage.remove_document_name);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDocumentConfirmation);
			ReusableMethods.waitForLoad();				
			String message=driver.findElement(DetailedViewPage.removeDocumentConfirmation).getText();
			ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
			ReusableMethods.click(DetailedViewPage.yes);
		}
	}
	public static void columnname_and_order_verification_for_a_workstream(DataTable Workstreams) throws IOException {
		List<Map<String, String>> workstream =Workstreams.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(documentdata1.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStream);

			//BOM table validation
			List<String> expected=new ArrayList<String>();
			expected.add("BOM Category");
			expected.add("BOM Name");
			expected.add("Assigned to");
			expected.add("State");
			expected.add("Status");
			expected.add("Due Date");
			expected.add("Partner");
			List<String> actual=new ArrayList<String>();
			driver.findElements(By.xpath("//thead//th")).size();
			for(int i=6;i<=12;i++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+i+"]")).getText();
				value.trim();
				actual.add(value);
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);

			//Risk table validation
			List<String> expected1=new ArrayList<String>();
			expected1.add("Applicable To");
			expected1.add("Risk Name");
			expected1.add("Assigned to");
			expected1.add("Status");
			expected1.add("Impact");
			expected1.add("Initiate Date");
			expected1.add("Due Date");
			List<String> actual1=new ArrayList<String>();
			for(int j=22;j<=28;j++) {
				String value=driver.findElement(By.xpath("(//thead//th)["+j+"]")).getText();
				value.trim();
				actual1.add(value);
			}
			boolean result1=expected1.equals(actual1);
			ReusableMethods.softAssertverification(result1, true);
		}
		DetailedViewPage.setWorkstream("//h5[contains(text(),'All Workstreams')]");
		ReusableMethods.click(DetailedViewPage.workStream);
	}

	public static void options_verification_for_workstreams(DataTable Workstreams) throws IOException {
		List<Map<String, String>> workstream =Workstreams.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = workstream.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> documentdata1 = workstream.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(documentdata1.get("Workstreams"));
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			String expected,actual;
			expected=driver.findElement(By.xpath(DetailedViewPage.viewdoc)).getText();
			if(documentdata1.get("Workstreams").equals("Product Ready")) {
				actual="View Scope Doc";
			}else {
				actual="View Plan Doc";
			}
			boolean result=expected.equals(actual);
			ReusableMethods.softAssertverification(result, true);
		}
	}

	public static void options_verification_for_workstreams_in_functional_lead(String Workstream, DataTable Sections) throws IOException {
		List<Map<String, String>> sections =Sections.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = sections.size();
		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> sectiondata = sections.get(anchor);
			ReusableMethods.waitForLoad();		
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			DetailedViewPage.setWorkstream(sectiondata.get("Options"));
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			//reusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			String expected;
			boolean result = false;
			int n=driver.findElements(By.xpath(DetailedViewPage.add_delete_doc)).size();
			for(int i=1;i<=n;i++) {
				String expected_xpath="("+DetailedViewPage.add_delete_doc+")["+i+"]";
				expected=driver.findElement(By.xpath(expected_xpath)).getText();
				if(Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=true;
					}else {
						result=false;
					}
				}
				else if(!Workstream.equals("Product Ready")) {
					if(expected.equals("Add/Delete Scope Doc") || expected.equals("Add Scope Doc"))  {
						result=false;
					}else {
						result=true;
					}
				}			
			}
			ReusableMethods.softAssertverification(result, true);
		}
	}

	public static void RYG_rule1(String bOM, String workstream) throws ParseException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitForLoad();
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					DetailedViewPage.setBOM(bOM);
					try{
						if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
							ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
							ReusableMethods.click(DetailedViewPage.view_editBom);
							break;
						}
					}catch (Exception e) {
						if(j==page_count-1) {
							System.out.println("Mentioned BOM is not present in UI");
						}
						else {
							System.out.println("Moving to next page to find the element");						
						}
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Only one page is there!!");
			DetailedViewPage.setBOM(bOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.view_editBom);
		}
		String due_dt,state;
		due_dt=ReusableMethods.getText(DetailedViewPage.bomDueDate);
		state=ReusableMethods.getText(DetailedViewPage.bomState);

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		Date firstDate = sdf.parse(due_dt);
		Date secondDate = new Date();

		long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

		ReusableMethods.softAssertverification(6, diff);

		if(!state.equals("Complete") && (diff>0)) {
		}
	}

	public static void RYG_risk_rules(String status,String bOM, String workstream) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitForLoad();
		String status_value = null;
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					try{
						if (driver.findElement(By.xpath("//tbody//td[6 and @title='"+bOM+"']")).isDisplayed()) {
							int n=driver.findElements(By.xpath("//tbody//td[9]")).size();		
							for(int i=1;i<n;i++) {
								String actual_bom=driver.findElement(By.xpath("//tbody//td[6]")).getText().trim();
								if(actual_bom.equals(bOM)) {
									status_value=driver.findElement(By.xpath("(//tbody//td[9])["+i+"]")).getText();
									break;
								}	
							}
						}
						break;
					}catch (Exception e) {
						if(j==page_count-1) {
							System.out.println("Mentioned BOM is not present in UI");
						}
						else {
							System.out.println("Moving to next page to find the element");						
						}
					}
				}
			}
		}catch(Exception e) {
			System.out.println("Only one page is there!!");
			try{
				if (driver.findElement(By.xpath("//tbody//td[6 and @title='"+bOM+"']")).isDisplayed()) {
					int n=driver.findElements(By.xpath("//tbody//td[9]")).size();		
					for(int i=1;i<n;i++) {
						String actual_bom=driver.findElement(By.xpath("//tbody//td[6]")).getText().trim();
						if(actual_bom.equals(bOM)) {
							status_value=driver.findElement(By.xpath("(//tbody//td[9])["+i+"]")).getText();
							break;
						}	
					}
				}
			}catch (Exception e1) {
				System.out.println("Mentioned BOM is not present in UI");						
			}
		}
		ReusableMethods.softAssertverification(status, status_value);	
	}

	public static void addrisk_to_a_workstream(String workstream, DataTable Riskdata) throws InterruptedException, IOException {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);

			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);	
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitForLoad();
			ReusableMethods.click(DetailedViewPage.workStreamAddRisk);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			ReusableMethods.enterData(DetailedViewPage.bomShortDescription,riskData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.bomDescription,riskData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
			ReusableMethods.enterData(DetailedViewPage.mitigation_plan,riskData1.get("MitigationPlan"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate,riskData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			ReusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//reusableMethods.softAssertverification(message," Risk Submitted! ");
			//reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);

		}
	}

	public static HashMap<String, String> workstream_bom_status_data(String workstream) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		HashMap<String,String> input_data = new HashMap<String,String>();
		try {
			if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
				int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
				for(int j=2;j<=page_count-1;j++ ) {
					By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
					ReusableMethods.click(page);
					int n=driver.findElements(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])")).size();		
					for(int i=1;i<=n;i++) {
						String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
						String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
						String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();

						input_data.put(bom_name, status + "-" + state);
					}
				}
			}					
		}catch (Exception e) {
			System.out.println("Only one page is there!!");				
			int n=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6]")).size();		
			for(int i=1;i<=n;i++) {
				String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
				String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
				String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();

				input_data.put(bom_name, status + "-" + state);				
			}
		}
		return input_data;	
	}

	public static void one_option_verification_for_BOM(String bOM, DataTable Options) throws IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			options.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM(bOM);
			int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				try {
					if(driver.findElement(By.xpath(DetailedViewPage.view_Bom)).isDisplayed()) {
						System.out.println("View BOM option is only available which is expected");
						ReusableMethods.click(DetailedViewPage.view_Bom);
					}
				}catch(Exception e) {
					System.out.println("View BOM option is Not available which is NOT expected");
				}
			}else {
				System.out.println("More than 1 option is available which is NOT expected");
			}
		}
	}

	public static void one_option_verification_for_Risk(String risk,String BOM, DataTable Options) throws IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			options.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM_Risk(BOM,risk);
			int option_size=driver.findElements(By.xpath(DetailedViewPage.total_risk_options)).size();
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
				try {
					if(driver.findElement(By.xpath(DetailedViewPage.view_risk)).isDisplayed()) {
						System.out.println("View Risk option is only available which is expected");
						ReusableMethods.click(DetailedViewPage.view_risk);
					}
				}catch(Exception e) {
					System.out.println("View Risk option is Not available which is NOT expected");
				}
			}else {
				System.out.println("More than 1 option is available which is NOT expected");
			}
		}
	}

	public static void assigned_to_me_BOM_options(String bOM, String workstream, String product, DataTable Optiondata) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> optiondata =Optiondata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = optiondata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(optiondata.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		By ele=By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button");
		ReusableMethods.click(ele);
		ReusableMethods.waitForLoad();
		List<String> expected=new ArrayList<String>();
		int options_size=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a")).size();
		for(int i=1;i<=options_size;i++) {
			String option_value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
					+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a)["+i+"]")).getText().trim();
			expected.add(option_value);
		}
		/*List<String> actual=new ArrayList<String>();
			int size = optiondata.size();
			for (int anchor = 0; anchor < size; anchor++) {
				actual.add(optiondata.get(anchor));

			}*/
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

	}

	public static void assigned_to_me_applicable_filter_options() throws IOException {
		ReusableMethods.IsElementExists(AssignedToMePage.bom_risk_search_button,true, "Assigned to Me Search Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.bulk_update_chklall,true,"Assigned to Me Search All Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.filter,true,"Assigned to Me Filter Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.bulkupdate,true,"Assigned to Me Bulk Edit Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.state,true,"Assigned to Me State");
		ReusableMethods.IsElementExists(AssignedToMePage.change_due_dt,true,"Assigned to Me Change due date");
		ReusableMethods.IsElementExists(AssignedToMePage.change_state,true,"Assigned to Me Change State");
		ReusableMethods.IsElementExists(AssignedToMePage.change_assigned_to,true,"Assigned to Me Change Assigned To");
		ReusableMethods.IsElementExists(AssignedToMePage.columnwise_search_button,true,"Assigned to Me Column Search Icon");
		ReusableMethods.IsElementExists(AssignedToMePage.columnwise_search_inputbox,true,"Assigned to Me Column Search Input");		
	}

	public static void options_verification_for_WS(String Workstream, DataTable Options) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(Workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.click(DetailedViewPage.workStreamButton);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_WS_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_WS_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_Product(String Product, DataTable Options) throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setProduct(Product);
		ReusableMethods.click(DetailedViewPage.product);
		ReusableMethods.click(DetailedViewPage.productButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_product_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_product_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_Risk(String risk,String BOM, DataTable Options) throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setBOM_Risk(BOM,risk);
		ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_risk_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_risk_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_BOM(String bOM, DataTable Options) throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setBOM(bOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_BOM_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void options_verification_for_ALL_WS(DataTable optionsdata) throws InterruptedException, IOException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All Workstreams");
		ReusableMethods.click(DetailedViewPage.all_workstream);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.allworkStreamoptions)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.allworkStreamoptions+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);		
	}
	public static void putWorkstreamData(String key, String value){
		workstream_data.put(key,value);
	}

	public static String getWorkstreamData(String key){
		return workstream_data.get(key);
	}

	public static HashMap<String,String> getWorkstreamData(){
		return workstream_data;
	}

	public static void options_verification_for_ALL_Products(DataTable optionsdata) throws InterruptedException, IOException {
		List<Map<String, String>> options =optionsdata.asMaps(String.class, String.class);
		WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All Products");
		ReusableMethods.click(DetailedViewPage.all_products);
		ReusableMethods.click(DetailedViewPage.allworkStreamButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.allworkStreamoptions)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.allworkStreamoptions+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);		
	}

	public static void filter_bulkedit_search_options_validations(DataTable filteroptions) throws InterruptedException, IOException {

		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream("All");
		ReusableMethods.click(DetailedViewPage.allworkStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(DetailedViewPage.filterIcon,true, "Filter Icon");
		ReusableMethods.IsElementExists(DetailedViewPage.selectall,true,"Select All check box");
		ReusableMethods.IsElementExists(DetailedViewPage.search,true,"Search Icon");
		ReusableMethods.IsElementExists(DetailedViewPage.bulk_edit,true,"Buld edit icon");

		List<Map<String, String>> options =filteroptions.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("FilterOptions"));
		}

		ReusableMethods.click(DetailedViewPage.filterIcon);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.filer_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.filer_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

		//Apply 1st option in filter 
		driver.findElement(By.xpath("(//li[@ng-if='fltHeader.isFilter']//span/following-sibling::label/..)[1]")).click();
		ReusableMethods.click(DetailedViewPage.filterapply);

		//Check Breadcrumb
		try {
			if(driver.findElement(By.xpath(DetailedViewPage.breadcrumb+"[1]")).isDisplayed()) {
				System.out.println("Breadcromb is getting displayed");
			}			
		}catch(Exception e) {
			System.out.println("Breadcromb is NOT getting displayed");
		}
		ReusableMethods.click(DetailedViewPage.breadcrumb+"[1]");

		ReusableMethods.click(DetailedViewPage.search);
		int search_size=driver.findElements(By.xpath(DetailedViewPage.search_input)).size();
		if(search_size>1) {
			System.out.println("Search Input is getting displayed");
		}else {
			System.out.println("Search Input is NOT getting displayed");
		}

		//Risk Search Option
		ReusableMethods.click(DetailedViewPage.bom_risk_toggle_button);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(DetailedViewPage.risk_selectall,true,"Select All check box");
		ReusableMethods.IsElementExists(DetailedViewPage.risk_search,true,"Search Icon");
		ReusableMethods.click(DetailedViewPage.risk_search);
		int n=driver.findElements(By.xpath(DetailedViewPage.search_input)).size();
		if(n>1) {
			System.out.println("Search Input is getting displayed");
		}else {
			System.out.println("Search Input is NOT getting displayed");
		}
	}
	
}