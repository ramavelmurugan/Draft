package stepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pageObjects.AssignedToMePage;
import pageObjects.DetailedViewPage;
import pageObjects.HeatMapPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;
import supportLibraries.Settings;

public class HeatMapStepDefs  extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(BOTStepDefs.class);
	}
	static WebDriver driver;
	HeatMapStepDefs(){
		this.driver = DriverManager.getWebDriver();
	}
	public static void verify_heatmap_worklist() throws InterruptedException, IOException {

		//WebDriver driver = DriverManager.getWebDriver();

		List<String> expected=new ArrayList<String>();
		expected.add("Product Ready");
		expected.add("Product Content Ready");
		expected.add("Ready to Operate");
		expected.add("Ready to Market");
		expected.add("Ready to Sell");
		expected.add("Ready to Solve");
		expected.add("Ready to Deliver");
		expected.add("Ready to Partner");
		expected.add("Ready to Train & Learn");
		expected.add("Ready to Support");
		expected.add("Ready to Adopt");
		expected.add("Release Management & Operation Dates");
		List<String> actual=new ArrayList<String>();
		int n=driver.findElements(By.xpath(HeatMapPage.workstream_list)).size();
		for(int i=1;i<=n;i++) {
			String value=driver.findElement(By.xpath(HeatMapPage.workstream_list+"["+i+"]")).getText().trim();
			actual.add(value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void validate_heatmap_risk_colors_percentage_icon() throws InterruptedException, IOException {
		//WebDriver driver = DriverManager.getWebDriver();

		ReusableMethods.click(HeatMapPage.completion_percentage);
		ReusableMethods.waitForLoad();
		ReusableMethods.IsElementExists(By.xpath(HeatMapPage.view_percentage),true,"View Percentage for product items");
		ReusableMethods.IsElementExists(HeatMapPage.toggle_risk,true,"At Risk toggle button");
		ReusableMethods.click(HeatMapPage.toggle_risk);
		ReusableMethods.waitForLoad();

		boolean flag=true;
		int size=driver.findElements(By.xpath(HeatMapPage.product_items)).size();
		for(int i=1;i<=size;i++) {
			String item_color=driver.findElement(By.xpath(HeatMapPage.product_items)).getAttribute("class");
			if(!item_color.contains("red") && !item_color.contains("yellow") && !item_color.contains("grey")) {
				flag=false;
			}
		}

		ReusableMethods.softAssertverification(flag, true);	
		
		ReusableMethods.click(HeatMapPage.toggle_risk);
		ReusableMethods.waitForLoad();
	}

}
