package stepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.LogStatus;

import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;
import cucumber.api.DataTable;

public class BOMStepDefs extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(BOMStepDefs.class);
	}
	
	static WebDriver driver;
	BOMStepDefs(){
		this.driver = DriverManager.getWebDriver();
	}
	private static HashMap<String,String> workstream_data=new HashMap<String,String>();
	private static String workstream_overall_status;
	private static String workstream_overall_status_afterupdate;
	private static String allworkstream_status;
	private static String allworkstream_status_afterupdate;
	private static int notrequired_count=0;
	public static void addBOM(DataTable BOMdata) throws InterruptedException, IOException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			String workstream=bomData1.get("Workstream");
			String product=bomData1.get("Product");

			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, product);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.workStreamButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			ReusableMethods.click(DetailedViewPage.workStreamAddBom);
			ReusableMethods.enterData(DetailedViewPage.bomShortDescription,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.bomDescription,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate,bomData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			//reusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//reusableMethods.softAssertverification(message,"Custom BOM Added.");
			//reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);		
		}
	}

	public static void editBOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		////WebDriver driver = DriverManager.getWebDriver();

		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			workstream_overall_status=workstreamoverallstatus(workstream);
			allworkstream_status=driver.findElement(DetailedViewPage.all_workstream).getText();
			String BOM=bomData1.get("BOM");
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[3]//dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						DetailedViewPage.setBOM(BOM);
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
								ReusableMethods.click(DetailedViewPage.view_editBom);
								break;
							}
						}catch (Exception e) {
							System.out.println("Moving to next page to find the element");
						}
					}
				}
			}catch(Exception e) {
				System.out.println("Only one page is there!!");
				DetailedViewPage.setBOM(BOM);
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				ReusableMethods.click(DetailedViewPage.view_editBom);
			}

			ReusableMethods.enterData(DetailedViewPage.BOM_short_desc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.BOM_desc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_state,bomData1.get("State"));
			if(bomData1.get("State").equals("Not Required")){ 
				notrequired_count+=1;	
			}
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.BOM_category,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.BOM_due_date,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(DetailedViewPage.add_document_to_BOM);
				ReusableMethods.enterData(DetailedViewPage.document_name_BOM,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(DetailedViewPage.document_link_BOM,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.remove_doc_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.remove_doc_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			/*if(!bomData1.get("RemoveDependency").equals("")) {
				AppEngine_DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(AppEngine_DetailedViewPage.remove_dependency_name);
				ReusableMethods.waitUntilElementVisible(AppEngine_DetailedViewPage.remove_dependency_confirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(AppEngine_DetailedViewPage.remove_dependency_confirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(AppEngine_DetailedViewPage.yes);
			}*/

			ReusableMethods.click(DetailedViewPage.addedButton);
			/*
			 * ReusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			 * ReusableMethods.waitForLoad(); String
			 * message=driver.findElement(DetailedViewPage.added_message).getText();
			 * ReusableMethods.softAssertverification(message,"BOM Updated!");
			 * ReusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);
			 */
		}
		workstream_overall_status_afterupdate=workstreamoverallstatus(workstream);
		allworkstream_status_afterupdate=driver.findElement(DetailedViewPage.all_workstream).getText();
		putWorkstreamData("Workstream Overall Status", workstream_overall_status);
		putWorkstreamData("Workstream Overall Status After Update", workstream_overall_status_afterupdate);
		putWorkstreamData("Workstream Not Required Update Count", String.valueOf(notrequired_count));
		putWorkstreamData("AllWorkstream Status", allworkstream_status);
		putWorkstreamData("AllWorkstream Status After Update", allworkstream_status_afterupdate);

	}

	public static String workstreamoverallstatus(String workstream) {	
		//WebDriver driver = DriverManager.getWebDriver();
		DetailedViewPage.setWorkstream(workstream);
		workstream_overall_status=driver.findElement(By.xpath(DetailedViewPage.workStream_overall_status)).getText();
		return workstream_overall_status;
	}
	
	public static void putWorkstreamData(String key, String value){
		workstream_data.put(key,value);
	}

	public static String getWorkstreamData(String key){
		return workstream_data.get(key);
	}

	public static HashMap<String,String> getWorkstreamData(){
		return workstream_data;
	}
	public static void cloneBOM(String workstream, DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		//WebDriver driver = DriverManager.getWebDriver();
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			ReusableMethods.waitForLoad();
			String BOM=bomData1.get("BOM");
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);

			//HashMap<String, String> edit_bom_data=getedit_BOMdata(BOM);
			//HashMap<String, String> clone_bom_data= getclone_BOMdata(BOM);

			//if(edit_bom_data.equals(clone_bom_data)) {
			ReusableMethods.click(DetailedViewPage.copyCloneBom);
			String clone_BOM_name=driver.findElement(DetailedViewPage.clone_BOM_name).getText();
			if(clone_BOM_name.contains("Copy of") && !clone_BOM_name.isEmpty()) {
				System.out.println("Clone BOM name contains 'Copy of'");
			}else {
				System.out.println("Clone BOM name does NOT contains 'Copy of'");
			}
			ReusableMethods.click(DetailedViewPage.cloneBOMNext);
			ReusableMethods.enterData(DetailedViewPage.cloneBomShortDesc,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.cloneBomDesc,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate,bomData1.get("DueDate"));
			if(!bomData1.get("AddDocumentName").equals("")) {
				ReusableMethods.click(DetailedViewPage.addDocumnetToBom);
				ReusableMethods.enterData(DetailedViewPage.bomDocumentName,bomData1.get("AddDocumentName"));
				ReusableMethods.enterData(DetailedViewPage.bomDocumentLinks,bomData1.get("AddDocumentLinks"));
				ReusableMethods.click(DetailedViewPage.add);
			}
			if(!bomData1.get("RemoveDocumentName").equals("")) {
				DetailedViewPage.set_BOMdocument(bomData1.get("RemoveDocumentName"));
				ReusableMethods.click(DetailedViewPage.remove_BOM_document_name);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDocumentConfirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.removeDocumentConfirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the link");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			if(!bomData1.get("RemoveDependency").equals("")) {
				DetailedViewPage.set_dependency(bomData1.get("RemoveDependency"));
				ReusableMethods.click(DetailedViewPage.removeDependencyName);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.removeDependencyConfirmation);
				ReusableMethods.waitForLoad();				
				String message=driver.findElement(DetailedViewPage.removeDependencyConfirmation).getText();
				ReusableMethods.softAssertverification(message,"Are you sure you want to remove the dependency?");
				ReusableMethods.click(DetailedViewPage.yes);
			}
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementVisible(DetailedViewPage.addedMessage);
			ReusableMethods.waitForLoad();
			String message=driver.findElement(DetailedViewPage.addedMessage).getText();
			ReusableMethods.softAssertverification(message,"BOM Updated!");
			ReusableMethods.click(DetailedViewPage.closeViewEditBomMessage);
			//}
		}
	}

	

	


		protected static HashMap<String, String> getedit_BOMdata(String BOM) throws IOException {
		HashMap<String, String> bomdata=new HashMap<String, String>();
		DetailedViewPage.setBOM(BOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		ReusableMethods.click(DetailedViewPage.view_editBom);
		bomdata.put("ShortDescription",ReusableMethods.getText(DetailedViewPage.bomShortDescription));
		bomdata.put("Description",ReusableMethods.getText(DetailedViewPage.bomDescription));
		bomdata.put("State",ReusableMethods.getText(DetailedViewPage.bomState));
		bomdata.put("Category",ReusableMethods.getText(DetailedViewPage.bomCategory));
		bomdata.put("DueDate",ReusableMethods.getText(DetailedViewPage.bomDueDate));

		//add cancel button click
		return bomdata;
	}

	protected static HashMap<String, String> getclone_BOMdata(String BOM) throws IOException {
		HashMap<String, String> bomdata=new HashMap<String, String>();
		DetailedViewPage.setBOM(BOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		ReusableMethods.click(DetailedViewPage.view_editBom);
		bomdata.put("ShortDescription",ReusableMethods.getText(DetailedViewPage.cloneBomShortDesc));
		bomdata.put("Description",ReusableMethods.getText(DetailedViewPage.cloneBomDesc));
		bomdata.put("State",ReusableMethods.getText(DetailedViewPage.bomState));
		bomdata.put("Category",ReusableMethods.getText(DetailedViewPage.bomCategory));
		bomdata.put("DueDate",ReusableMethods.getText(DetailedViewPage.bomDueDate));

		//add cancel button click
		return bomdata;
	}

	protected static HashMap<String, String> workstream_bom_status_data(String workstream) throws IOException {
		//WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.waitForLoad();
		DetailedViewPage.setWorkstream(workstream);
		ReusableMethods.click(DetailedViewPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		HashMap<String,String> input_data = new HashMap<String,String>();
		try {
			if (ReusableMethods.isDisplayed(DetailedViewPage.paginationCheck)) {
				int page_count = ReusableMethods.getElementsSize(DetailedViewPage.pageCounts);
				for(int j=2;j<=page_count-1;j++ ) {
					DetailedViewPage.setPageCount(page_count);
					ReusableMethods.click(DetailedViewPage.pageCount);
					int n = ReusableMethods.getElementsSize(DetailedViewPage.bomDetailsDisplayed);

					for(int i=1;i<=n;i++) {
						String bom_name=ReusableMethods.getText("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]");
						String status=ReusableMethods.getText("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]");
						String state=ReusableMethods.getText("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]");

						input_data.put(bom_name, status + "-" + state);
					}
				}
			}					
		} catch (Exception e) {
			System.out.println("Only one page is there!!");				
			int n=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6]")).size();		
			for(int i=1;i<=n;i++) {
				String bom_name=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[6])["+i+"]")).getText().trim();
				String status=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[9])["+i+"]")).getText().trim();
				String state=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[4]/table/tbody//td[8])["+i+"]")).getText().trim();

				input_data.put(bom_name, status + "-" + state);				
			}
		}
		return input_data;	
	}

	public static void addBOM_FL(DataTable BOMdata) throws InterruptedException, IOException {
		List<Map<String, String>> bomData =BOMdata.asMaps(String.class, String.class);
		int size = bomData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> bomData1 = bomData.get(anchor);
			String Product=bomData1.get("Product");
			String workstream=bomData1.get("Workstream");
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_list, workstream);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			DetailedViewPage.setProduct(Product);
			ReusableMethods.click(DetailedViewPage.product);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.productButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			ReusableMethods.click(DetailedViewPage.productAddBom);
			ReusableMethods.enterData(DetailedViewPage.bomShortDescription,bomData1.get("ShortDescription"));
			ReusableMethods.enterData(DetailedViewPage.bomDescription,bomData1.get("Description"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomState,bomData1.get("State"));
			ReusableMethods.selectDataByVisibleText(DetailedViewPage.bomCategory,bomData1.get("Category"));
			ReusableMethods.enterData(DetailedViewPage.bomDueDate,bomData1.get("DueDate"));
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			//reusableMethods.waitForLoad();
			//String message=driver.findElement(DetailedViewPage.added_message).getText();
			//reusableMethods.softAssertverification(message,"Custom BOM Added.");
			//reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message);		
		}
	}

	public static void one_option_verification_for_BOM(String bOM, DataTable Options) throws IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		//WebDriver driver = DriverManager.getWebDriver();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			options.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM(bOM);
			int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
			if(option_size==1) {
				ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
				try {
					if(driver.findElement(By.xpath(DetailedViewPage.view_Bom)).isDisplayed()) {
						System.out.println("View BOM option is only available which is expected");
						ReusableMethods.click(DetailedViewPage.view_Bom);
					}
				}catch(Exception e) {
					System.out.println("View BOM option is Not available which is NOT expected");
				}
			}else {
				System.out.println("More than 1 option is available which is NOT expected");
			}
		}
	}

	public static void assigned_to_me_BOM_options(String bOM, String workstream, String product, DataTable Optiondata) throws InterruptedException, IOException {
		//WebDriver driver = DriverManager.getWebDriver();
		List<Map<String, String>> optiondata =Optiondata.asMaps(String.class, String.class);
		List<String> actual=new ArrayList<String>();
		int size = optiondata.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(optiondata.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		By ele=By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button");
		ReusableMethods.click(ele);
		ReusableMethods.waitForLoad();
		List<String> expected=new ArrayList<String>();
		int options_size=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
				+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a")).size();
		for(int i=1;i<=options_size;i++) {
			String option_value=driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div[4]/table/tbody"
					+ "//td[text()='"+workstream+"']/..//td[text()='"+product+"']/..//td[text()='"+bOM+"']/..//button/..//a)["+i+"]")).getText().trim();
			expected.add(option_value);
		}
		/*List<String> actual=new ArrayList<String>();
			int size = optiondata.size();
			for (int anchor = 0; anchor < size; anchor++) {
				actual.add(optiondata.get(anchor));

			}*/
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);

	}

	public static void options_verification_for_BOM(String bOM, DataTable Options) throws InterruptedException, IOException {
		List<Map<String, String>> options =Options.asMaps(String.class, String.class);
		//WebDriver driver = DriverManager.getWebDriver();
		List<String> actual=new ArrayList<String>();
		int size = options.size();
		for (int anchor = 0; anchor < size; anchor++) {
			actual.add(options.get(anchor).get("Options"));
		}
		ReusableMethods.waitForLoad();
		DetailedViewPage.setBOM(bOM);
		ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
		Thread.sleep(2000);
		List<String> expected=new ArrayList<String>();
		int option_size=driver.findElements(By.xpath(DetailedViewPage.total_BOM_options)).size();
		for(int i=1;i<=option_size;i++) {
			String val_xpath=DetailedViewPage.total_BOM_options+"["+i+"]";
			String option_value=driver.findElement(By.xpath(val_xpath)).getText().trim();
			expected.add(option_value);
		}
		boolean result=expected.equals(actual);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void validate_summary_status_BOM_cat(String product, String workstream) throws InterruptedException, IOException {
		//WebDriver driver = DriverManager.getWebDriver();
		OLAStepDefs.select_page("Summary Status");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		int cat_size=driver.findElements(By.xpath(SummaryStatusPage.summary_bom_cat_values)).size();
		HashMap<String,String> summary_bom = new HashMap<String,String>();
		HashMap<String,String> dashboard_bom = new HashMap<String,String>();
		for (int i=1;i<=cat_size;i++) {
			String val=driver.findElement(By.xpath(SummaryStatusPage.summary_bom_cat_values+"["+i+"]")).getText().trim();
			summary_bom.put("BOM -"+i, val);
		}
		OLAStepDefs.select_page("Dashboard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		if(cat_size>4) {
			for (int i=1;i<=(cat_size/4)+1;i++) {
				try {
					if(driver.findElement(By.xpath(DashboardPage.dashboard_arrow)).isDisplayed()){
						DashboardPage.setProduct_tile(workstream);
						int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
						for(int j=1;j<=size;j++) {
							String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
							dashboard_bom.put("BOM -"+j, val1);	
						}
					}
					ReusableMethods.click(By.xpath(DashboardPage.dashboard_arrow));	
				}catch(Exception e) {
					System.out.println("For more than 4 BOM categories Left/right arrow is not available in dashboard Product/Workstream tile!!");
				}
			}
		}else {
			System.out.println("Les than or equal to 4 BOM categories!!");
			DashboardPage.setProduct_tile(product);
			int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
			for(int j=1;j<=size;j++) {
				String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
				dashboard_bom.put("BOM -"+j, val1);	
			}
		}
		boolean result=summary_bom.equals(dashboard_bom);
		ReusableMethods.softAssertverification(result, true);
	}
	public static void addrisk_to_existing_BOM(String BOM, DataTable Riskdata) {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		//WebDriver driver = DriverManager.getWebDriver();
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[2]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						ReusableMethods.waitForLoad();
						DetailedViewPage.setBOM(BOM);
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
								ReusableMethods.click(DetailedViewPage.addRiskToBOM);
								break;
							}
						}catch (Exception e) {
							if(j==page_count-1) {
								System.out.println("BOM is not present in the UI");
							}else {
								System.out.println("Moving to next page to find the element");
							}
						}
					}
					ReusableMethods.enterData(DetailedViewPage.bomShortDescription,riskData1.get("ShortDescription"));
					ReusableMethods.enterData(DetailedViewPage.bomDescription,riskData1.get("Description"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
					ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
					ReusableMethods.enterData(DetailedViewPage.bomDueDate,riskData1.get("DueDate"));
					ReusableMethods.click(DetailedViewPage.addedButton);
					//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
					ReusableMethods.waitForLoad();
					//String message=driver.findElement(DetailedViewPage.added_message).getText();
					//reusableMethods.softAssertverification(message," Risk Submitted! ");
					//reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message); 
				}
			}catch(Exception e1) {
				System.out.println("Only one page is there!!");
				try{
					if (driver.findElement(By.xpath(DetailedViewPage.addedBomOptionsButton)).isDisplayed()) {
						ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
						ReusableMethods.click(DetailedViewPage.addRiskToBOM);
						ReusableMethods.enterData(DetailedViewPage.bomShortDescription,riskData1.get("ShortDescription"));
						ReusableMethods.enterData(DetailedViewPage.bomDescription,riskData1.get("Description"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_impact,riskData1.get("Impact"));
						ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
						ReusableMethods.enterData(DetailedViewPage.bomDueDate,riskData1.get("DueDate"));
						ReusableMethods.click(DetailedViewPage.addedButton);
						//reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
						ReusableMethods.waitForLoad();
					}
				}catch (Exception e) {	
					System.out.println("BOM is not present in the UI");
				}			
			}
		}
	}

	public static void editrisk_to_existing_BOM(String workstream,DataTable Riskdata) throws InterruptedException, IOException {
		List<Map<String, String>> riskData =Riskdata.asMaps(String.class, String.class);
		//WebDriver driver = DriverManager.getWebDriver();
		int size = riskData.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> riskData1 = riskData.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setWorkstream(workstream);
			ReusableMethods.click(DetailedViewPage.workStream);
			try {
				if (driver.findElement(By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)[1]")).isDisplayed()){
					int page_count=driver.findElements(By.xpath("//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a")).size();
					for(int j=2;j<=page_count-1;j++ ) {
						By page=By.xpath("(//*[@id='jsListView']/div[3]/div/div/div[5]/div/dir-pagination-controls/ul/li/a)["+j+"]");
						ReusableMethods.click(page);
						DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
						try{
							if (driver.findElement(By.xpath(DetailedViewPage.view_editRiskOptionsButton)).isDisplayed()) {
								ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
								ReusableMethods.click(DetailedViewPage.view_editRisk);
								break;
							}
						}catch (Exception e) {
							System.out.println("Moving to next page to find the element");
						}
					}

				}
			}catch(Exception e) {
				System.out.println("Only one page is there!!");
				DetailedViewPage.setBOM_Risk(riskData1.get("BOMname"), riskData1.get("Riskname"));
				ReusableMethods.click(DetailedViewPage.view_editRiskOptionsButton);
				ReusableMethods.click(DetailedViewPage.view_editRisk);
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_shortdescription,riskData1.get("ShortDescription"));
				ReusableMethods.enterData(DetailedViewPage.editrisk_BOM_description,riskData1.get("Description"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.editrisk_BOM_impactstatus,riskData1.get("Impact"));
				ReusableMethods.selectDataByVisibleText(DetailedViewPage.Risk_status,riskData1.get("RiskStatus"));
				ReusableMethods.enterData(DetailedViewPage.bomDueDate,riskData1.get("DueDate"));
				ReusableMethods.click(DetailedViewPage.addedButton);
				ReusableMethods.waitUntilElementVisible(DetailedViewPage.addedMessage);
				ReusableMethods.waitForLoad();
				String message=driver.findElement(DetailedViewPage.addedMessage).getText();
				ReusableMethods.softAssertverification(message," Risk Updated! ");
				ReusableMethods.click(DetailedViewPage.closeViewEditBomMessage); 
			}
		}
	}

	public static void adddependency_to_existing_BOM(String BOM, DataTable Dependencydata) throws InterruptedException, IOException {
		List<Map<String, String>> dependencydata =Dependencydata.asMaps(String.class, String.class);
		int size = dependencydata.size();

		for (int anchor = 0; anchor < size; anchor++) {
			Map<String,String> dependencydata1 = dependencydata.get(anchor);
			ReusableMethods.waitForLoad();
			DetailedViewPage.setBOM(BOM);
			ReusableMethods.click(DetailedViewPage.addedBomOptionsButton);
			ReusableMethods.click(DetailedViewPage.addDependencyToBOM);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_prod_family_dropdown);
			ReusableMethods.enterData_without_TAB(DetailedViewPage.dependent_BOM_prod_family_input,dependencydata1.get("DependentBOMProductFamily"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMProductFamily"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.dependent_BOM_workstream_dropdown);
			ReusableMethods.enterData_without_TAB(DetailedViewPage.dependent_BOM_workstream_input,dependencydata1.get("DependentBOMWorkstream"));
			DetailedViewPage.setDependent_BOM_Value(dependencydata1.get("DependentBOMWorkstream"));
			ReusableMethods.click(DetailedViewPage.dependent_BOM_value);
			ReusableMethods.click(DetailedViewPage.addedButton);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

			/*reusableMethods.waitUntilElementVisible(DetailedViewPage.added_message);
			reusableMethods.waitForLoad();
			String message=driver.findElement(DetailedViewPage.added_message).getText();
			reusableMethods.softAssertverification(message,"Dependency added.");
			reusableMethods.click(DetailedViewPage.close_view_edit_BOM_message); 
			 */
		}		
	}

}