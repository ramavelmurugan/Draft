package stepDefinitions;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.HeatMapPage;
import pageObjects.ScoreCardPage;
import pageObjects.ScorecardStatusPage;
import pageObjects.SummaryStatusPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;
import supportLibraries.Settings;

public class Summary_Scorecard_StepDefs extends MasterStepDefs {

	private static Logger log;
	private static Properties properties = Settings.getInstance();

	static {
		log = Logger.getLogger(DashboardStepDefs.class);
	}

	public static void validate_summary_status_FL(String Product,String workstream,String Status) 
			throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		ReusableMethods.IsElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.IsElementExists(SummaryStatusPage.status,false,"Status Dropdown");
		ReusableMethods.click(SummaryStatusPage.status);
		String tilecolor_class_attribute_value="";
		if(Status.equals("none")) {
			ReusableMethods.click(SummaryStatusPage.none);
			tilecolor_class_attribute_value="panel-heading ng-binding panGrey";
			/*
			 * for none option submit button wont be enabled
			 */
		}
		else if(Status.equals("On Track")) {
			ReusableMethods.click(SummaryStatusPage.on_track);
			tilecolor_class_attribute_value="panel-heading ng-binding panGreen";
		}
		else if(Status.equals("Risk")) {
			ReusableMethods.click(SummaryStatusPage.risk);
			tilecolor_class_attribute_value="panel-heading ng-binding panYellow";
		}
		else if(Status.equals("Critical")) {
			ReusableMethods.click(SummaryStatusPage.critical);
			tilecolor_class_attribute_value="panel-heading ng-binding panRed";
		}
		ReusableMethods.click(SummaryStatusPage.submit);
		SummaryStatusPage.setWorkstream(Product);
		String product_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=product_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}

		OLAStepDefs.select_page("Dashboard");
		DashboardPage.setProduct_tile_color(Product,tilecolor_class_attribute_value);
		ReusableMethods.IsElementExists(By.xpath(DashboardPage.product_tile_color),true,"Tile after status updated");
	}

	public static void validate_summary_status(String Product,String workstream,String Status) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		Thread.sleep(2000);
		ReusableMethods.IsElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.IsElementExists(SummaryStatusPage.status,false,"Status Dropdown");		
		ReusableMethods.click(SummaryStatusPage.submit);
		Thread.sleep(2000);

		//SummaryStatusPage.setWorkstream(workstream);
		String workstream_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
		}
	}

	public static void validate_scorecard_for_product(String product, String Status) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		OLAStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.IsElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.IsElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.IsElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.IsElementExists(ScoreCardPage.status_update,true,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScoreCardPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScoreCardPage.clear,true,"Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.IsElementExists(ScoreCardPage.highlight_changes_since,true,"Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		}
		else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		}
		else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		}
		else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Open");
		ReusableMethods.IsElementEnabled(ScoreCardPage.submit,false,"Submit");

		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.IsElementExists(ScoreCardPage.submit,true,"Submit");
		ReusableMethods.IsElementExists(ScoreCardPage.save,true,"Save");
		ReusableMethods.click(ScoreCardPage.submit);

		ReusableMethods.IsElementExists(ScoreCardPage.approver_section,true,"Approver Section");
		String Approver_name=driver.findElement(ScoreCardPage.approver_name).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));
		String product_name=driver.findElement(ScoreCardPage.product_name).getText().trim();
		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		ReusableMethods.IsElementExists(ScoreCardPage.progress_section,true,"Progress Section");
	}


	public static void validate_scorecard_for_workstream(String workstream, String Status) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		OLAStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		ReusableMethods.IsElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.IsElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.IsElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.IsElementExists(ScoreCardPage.status_update,true,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScoreCardPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScoreCardPage.clear,true,"Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.IsElementExists(ScoreCardPage.highlight_changes_since,true,"Highlight Changes Since");
		ReusableMethods.click(ScoreCardPage.status_update);
		ReusableMethods.click(ScoreCardPage.tracking_status);

		if(Status.equals("none")) {
			ReusableMethods.click(ScoreCardPage.none);
		}
		else if(Status.equals("On Track")) {
			ReusableMethods.click(ScoreCardPage.on_track);
		}
		else if(Status.equals("Risk")) {
			ReusableMethods.click(ScoreCardPage.risk);
		}
		else if(Status.equals("Critical")) {
			ReusableMethods.click(ScoreCardPage.critical);
		}
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Open");
		ReusableMethods.IsElementEnabled(ScoreCardPage.submit,false,"Submit");

		ReusableMethods.selectDataByVisibleText(ScoreCardPage.workstream_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.pm_review, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.gm_approval, "Completed");
		ReusableMethods.selectDataByVisibleText(ScoreCardPage.submit_to_NPI, "Completed");
		ReusableMethods.IsElementExists(ScoreCardPage.submit,true,"Submit");
		ReusableMethods.IsElementExists(ScoreCardPage.save,true,"Save");
		ReusableMethods.click(ScoreCardPage.submit);

		ReusableMethods.IsElementExists(ScoreCardPage.approver_section,true,"Approver Section");
		String Approver_name=driver.findElement(ScoreCardPage.approver_name).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.IsElementExists(ScoreCardPage.progress_section,true,"Progress Section");

	}

	public static void validate_summary_status_BOM_cat(String product, String workstream) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		OLAStepDefs.select_page("Summary Status");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		int cat_size=driver.findElements(By.xpath(SummaryStatusPage.summary_bom_cat_values)).size();
		HashMap<String,String> summary_bom = new HashMap<String,String>();
		HashMap<String,String> dashboard_bom = new HashMap<String,String>();
		for (int i=1;i<=cat_size;i++) {
			String val=driver.findElement(By.xpath(SummaryStatusPage.summary_bom_cat_values+"["+i+"]")).getText().trim();
			summary_bom.put("BOM -"+i, val);
		}
		OLAStepDefs.select_page("Dashboard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		if(cat_size>4) {
			for (int i=1;i<=(cat_size/4)+1;i++) {
				try {
					if(driver.findElement(By.xpath(DashboardPage.dashboard_arrow)).isDisplayed()){
						DashboardPage.setProduct_tile(workstream);
						int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
						for(int j=1;j<=size;j++) {
							String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
							dashboard_bom.put("BOM -"+j, val1);	
						}
					}
					ReusableMethods.click(By.xpath(DashboardPage.dashboard_arrow));	
				}catch(Exception e) {
					System.out.println("For more than 4 BOM categories Left/right arrow is not available in dashboard Product/Workstream tile!!");
				}
			}
		}else {
			System.out.println("Les than or equal to 4 BOM categories!!");
			DashboardPage.setProduct_tile(product);
			int size=driver.findElements(By.xpath(DashboardPage.dashboard_bom_cat_values)).size();
			for(int j=1;j<=size;j++) {
				String val1=driver.findElement(By.xpath(DashboardPage.dashboard_bom_cat_values+"["+j+"]")).getText().trim();
				dashboard_bom.put("BOM -"+j, val1);	
			}
		}
		boolean result=summary_bom.equals(dashboard_bom);
		ReusableMethods.softAssertverification(result, true);
	}

	public static void test() {
		getDetailedViewColumnHeader();
	}

	protected static HashMap<String,String> getDetailedViewColumnHeader() {

		WebDriver driver = DriverManager.getWebDriver();

		HashMap<String, String> columnData = new HashMap<String, String>();

		int headerColumnCount = driver.findElements((DetailedViewPage.columnHeaderDetailedView)).size();

		String getAriaHidden[] = new String[headerColumnCount-5];
		String getText[] = new String[headerColumnCount-5];

		for (int index = 0; index < (headerColumnCount - 5); index++) {

			DetailedViewPage.setColumnHeaderDetails(index+5);

			getText[index] = driver.findElement(
					By.xpath(DetailedViewPage.columnHeaders)).getAttribute("textContent").trim();

			getAriaHidden[index] = driver.findElement(
					By.xpath(DetailedViewPage.columnHeaders)).getAttribute("aria-hidden");

			columnData.put(getText[index], getAriaHidden[index]);
		}
		System.out.println(columnData);
		return columnData;
	}

	public static void validate_summary_status(String Product,String workstream) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,true,"Edit Button");
		ReusableMethods.click(SummaryStatusPage.edit);
		Thread.sleep(2000);
		ReusableMethods.enterData(SummaryStatusPage.scorecard_summary_ready_test, "Automation Testing");
		Thread.sleep(2000);
		ReusableMethods.IsElementExists(SummaryStatusPage.save,true,"Save Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.submit,true,"Submit Button");
		ReusableMethods.IsElementExists(SummaryStatusPage.cancel,true,"Cancel");
		ReusableMethods.IsElementExists(SummaryStatusPage.status,false,"Status Dropdown");	
		ReusableMethods.click(SummaryStatusPage.submit);
		Thread.sleep(2000);

		String workstream_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			//System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			//System.out.println("Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent);
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));

		}
	}
	public static void validate_product_risk_summary_status(String product, String workstream) throws IOException, InterruptedException {
		WebDriver driver = DriverManager.getWebDriver();

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		ReusableMethods.IsElementExists(By.xpath(SummaryStatusPage.summary_bom_cat_values),true,"BOM category");
		ReusableMethods.IsElementExists(By.xpath(SummaryStatusPage.summary_bom_cat_progressbar),true,"BOM category Progress Bar");
		ReusableMethods.IsElementExists(By.xpath(SummaryStatusPage.summary_bom_cat_percentage),true,"BOM category completion percentage");
		ReusableMethods.IsElementExists(By.xpath(SummaryStatusPage.summary_bom_cat_comments),true,"BOM category status comments");
		ReusableMethods.IsElementExists(SummaryStatusPage.scorecard_expand_collapse_button,true,"Scorecard Summary expand collapse button");
		ReusableMethods.IsElementExists(SummaryStatusPage.productsummary_expand_collapse_button,true,"Product Summary expand collapse button");
		ReusableMethods.IsElementExists(SummaryStatusPage.risksummary_expand_collapse_button,true,"Risk Summary expand collapse button");
		ReusableMethods.IsElementExists(By.xpath(SummaryStatusPage.workStream_attachment),true,"Workstream attachment");
		String bom_cat_color=driver.findElement(By.xpath(SummaryStatusPage.summary_bom_cat_color)).getAttribute("ng-if");
		System.out.println("BOM category Status color = "+bom_cat_color);

		boolean flag=true;
		int size=driver.findElements(By.xpath("(//*[@id='jsSummaryStatusView']/div[1]/div[3]/div[2]//table/tbody//td[6])")).size();
		for(int i=1;i<=size;i++) {
			String status = driver.findElement(By.xpath("(//*[@id='jsSummaryStatusView']/div[1]/div[3]/div[2]//table/tbody//td[6])["+i+"]")).getText().trim();
			if(!status.equals("Open Unmitigated") && !status.equals("Open with Mitigation Plan")) {
				flag=false;
			}
		}

		ReusableMethods.softAssertverification(flag, true);	
	}

	public static void validate_summary_status_readonly_product(String Product,String workstream) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		SummaryStatusPage.setWorkstream(workstream);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, Product);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,false,"Edit Button");

		String workstream_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
	}

	public static void validate_summary_status_readonly_workstream(String workstream,String Product) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		
		ReusableMethods.waitForLoad();
		SummaryStatusPage.setWorkstream(Product);
		ReusableMethods.click(SummaryStatusPage.workStream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, workstream);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.IsElementExists(SummaryStatusPage.edit,false,"Edit Button");

		String workstream_completed_data=driver.findElement(By.xpath(SummaryStatusPage.worktream_completed_data)).getText().trim();
		String[] bom_data=workstream_completed_data.split("/");
		int total_bom=Integer.parseInt(bom_data[1].trim());
		String str1[]=bom_data[0].split(":");
		int completed_bom=Integer.parseInt(str1[1].trim());

		double percent;
		percent=(completed_bom*100)/total_bom;
		percent=Math.round(percent*100.0)/100.0;
		String completion_percentage=driver.findElement(SummaryStatusPage.completion_percentage).getText().trim();
		if(String.valueOf(percent).contains(completion_percentage.split("%")[0])) {
			System.out.println("Percentage validation is successful in Summary status!!!!!!!!!!!");
			test.log(LogStatus.PASS, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
		else { 
			System.out.println("Incorrect Percentage value in Summary status!!!!!!!!!!!");
			test.log(LogStatus.FAIL, "Actual Percentage = "+completion_percentage+" Calculated Percentage = "+percent, test.addScreenCapture(capture(driver)));
		}
	}

	public static void validate_scorecard_for_workstream_readonly(String workstream, String Status) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		OLAStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		ReusableMethods.IsElementExists(DetailedViewPage.workstream_dropdown,false,"Product drop down");
		ReusableMethods.IsElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.IsElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.IsElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.IsElementExists(ScoreCardPage.status_update,false,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScoreCardPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScoreCardPage.clear,true,"Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.IsElementExists(ScoreCardPage.highlight_changes_since,true,"Highlight Changes Since");

		ReusableMethods.IsElementExists(ScoreCardPage.approver_section,true,"Approver Section");
		String Approver_name=driver.findElement(ScoreCardPage.approver_name).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.IsElementExists(ScoreCardPage.progress_section,true,"Progress Section");
	}

	public static void validate_scorecard_for_product_readonly(String product, String Status) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		OLAStepDefs.select_page("Scorecard");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.selectDataByVisibleText(DetailedViewPage.workstream_dropdown, product);
		ReusableMethods.IsElementExists(ScoreCardPage.progress,true,"Scorecard Progress");
		ReusableMethods.IsElementExists(ScoreCardPage.scorecardapprover,true,"Scorecard  Approver");
		ReusableMethods.IsElementExists(ScoreCardPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScoreCardPage.download,true,"Download");
		ReusableMethods.IsElementExists(ScoreCardPage.status_update,false,"Status Update");
		ReusableMethods.click(ScoreCardPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScoreCardPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScoreCardPage.clear,true,"Clear");
		ReusableMethods.click(ScoreCardPage.apply);
		ReusableMethods.IsElementExists(ScoreCardPage.highlight_changes_since,true,"Highlight Changes Since");

		ReusableMethods.IsElementExists(ScoreCardPage.approver_section,true,"Approver Section");
		String Approver_name=driver.findElement(ScoreCardPage.approver_name).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));
		String product_name=driver.findElement(ScoreCardPage.product_name).getText().trim();
		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		ReusableMethods.IsElementExists(ScoreCardPage.progress_section,true,"Progress Section");
	}

	public static void validate_scorecard_status_page(String product) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		ScorecardStatusPage.set_product(product);
		ReusableMethods.click(ScorecardStatusPage.scorecard_icon);
		Thread.sleep(1000);
		ReusableMethods.IsElementExists(ScorecardStatusPage.product_dropdowns,true,"Scorecard Status Product Drop Downs");
		ReusableMethods.IsElementExists(ScorecardStatusPage.scorecard_workstream_list,true,"Scorecard Status Workstream List");
		ReusableMethods.IsElementExists(ScorecardStatusPage.calendar,true,"Calendar");
		ReusableMethods.IsElementExists(ScorecardStatusPage.download,true,"Download");
		ReusableMethods.click(ScorecardStatusPage.calendar);
		Thread.sleep(1000);
		driver.findElement(ScorecardStatusPage.date).sendKeys("31-12-2022");
		ReusableMethods.IsElementExists(ScorecardStatusPage.clear,true,"Clear");
		ReusableMethods.click(ScorecardStatusPage.apply);
		ReusableMethods.IsElementExists(ScorecardStatusPage.highlight_changes_since,true,"Highlight Changes Since");

		ReusableMethods.click(ScorecardStatusPage.download);
		Thread.sleep(1000);

		ReusableMethods.IsElementExists(ScorecardStatusPage.approver_name_scorecard,true,"Approver Section");
		String Approver_name=driver.findElement(ScorecardStatusPage.approver_name_scorecard).getText().trim();
		test.log(LogStatus.INFO, "Approver Name: "+Approver_name, test.addScreenCapture(capture(driver)));

		ReusableMethods.IsElementExists(ScorecardStatusPage.status_scorecard,true,"Status");
		String status=driver.findElement(ScorecardStatusPage.status_scorecard).getText().trim();
		test.log(LogStatus.INFO, "Status: "+status, test.addScreenCapture(capture(driver)));

		String product_name=driver.findElement(ScorecardStatusPage.product_name_scorecard).getText().trim();
		if(product_name.contains(product)) {
			test.log(LogStatus.PASS, "Product name is getting displayed in Approver section of Scorecard Status Page!!"+product_name, test.addScreenCapture(capture(driver)));
		}
		else {
			test.log(LogStatus.FAIL, "Product name is NOT getting displayed in Approver section of Scorecard Status Page!!"+product_name, test.addScreenCapture(capture(driver)));
		}
	}

	public static void validate_expand_collapse() throws IOException, InterruptedException {
		WebDriver driver = DriverManager.getWebDriver();

		int n= driver.findElements(By.xpath(HeatMapPage.product_dropdowns)).size();
		
		for(int i=1;i<n;i++) {
			//String product_name=driver.findElement(By.xpath(ScorecardStatusPage.product_dropdowns+"["+i+"]")).getText().trim();		
			ReusableMethods.click(By.xpath(HeatMapPage.product_dropdowns+"["+i+"]"));
			Thread.sleep(1000);
		}
		OLAStepDefs.select_page("Scorecard Status");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

		OLAStepDefs.select_page("Heat Map");
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);

	}

	public static void validate_heatmap_for_workstream_product(String workstream, String product) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();

		int n= driver.findElements(By.xpath(HeatMapPage.workstream_list)).size();
		for(int i=1;i<n;i++) {
			String ws_name=driver.findElement(By.xpath(HeatMapPage.workstream_list+"["+i+"]")).getText().trim();	
			if(ws_name.equals(workstream)) {
				ReusableMethods.click(By.xpath(HeatMapPage.workstream_list+"["+i+"]"));
				Thread.sleep(1000);break;
			}
			else {
				test.log(LogStatus.FAIL, workstream+" Workstream not available ",test.addScreenCapture(capture(driver)));
			}
		}
		HeatMapPage.set_product(product);
		ReusableMethods.IsElementExists(HeatMapPage.product_tile,true,"Product tile in Heat Map Dashboard");
		ReusableMethods.click(By.xpath(HeatMapPage.product_tile));
		Thread.sleep(1000);
		ReusableMethods.IsElementExists(HeatMapPage.scorecard_summary,true,"Scorecard Summary in Heat Map");
		/*
		 * Click back button 2 time to reach heat map page
		 */
		
		ReusableMethods.click(HeatMapPage.back);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		ReusableMethods.click(HeatMapPage.back);
		ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
		
		//click any of the Product WS intersection(box)
		ReusableMethods.click(By.xpath(HeatMapPage.product_items+"[1]"));
		Thread.sleep(1000);
		ReusableMethods.IsElementExists(HeatMapPage.scorecard_summary,true,"Scorecard Summary in Heat Map");

	}

}
