package stepDefinitions;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.DataTable;
import pageObjects.DashboardPage;
import pageObjects.DetailedViewPage;
import pageObjects.LoginPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;

import supportLibraries.Settings;
import supportLibraries.Util;

public class GeneralStepDefs extends MasterStepDefs {

	private static Logger log;
	static {
		log = Logger.getLogger(GeneralStepDefs.class);
	}

	private static Properties properties = Settings.getInstance();
	private static HashMap<String,String> workstreamData = new HashMap<String,String>();
	private static String workstreamOverallStatus;
	
	protected static void putWorkstreamData(String key, String value){
		workstreamData.put(key,value);
	}

	protected static String getWorkstreamData(String key){
		return workstreamData.get(key);
	}

	protected static HashMap<String,String> getWorkstreamData(){
		return workstreamData;
	}

	protected static String getWorkstreamOverallStatus(String workstream) {	
		try {
			DetailedViewPage.setWorkstream(workstream);
			workstreamOverallStatus = ReusableMethods.getText(DetailedViewPage.workStreamOverallStatus);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return workstreamOverallStatus;
	}
	
	/**
	 * Function to Launch the Application
	 *  
	 * @throws IOException
	 */
	protected static void launchApplicationWebDriver() throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			properties = Settings.getInstance();
			String URL = properties.getProperty("ApplicationUrl");
			driver.get(URL);
			currentScenario.embed(Util.takeScreenshot(driver),"image/png");
			assertTrue(driver.getTitle().contains("Service Portal - Offer Lifecycle Operations"));
			test = report.startTest(currentScenario.getName());
			test.log(LogStatus.PASS, "Navigated to the specified URL", 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Unable to navigate to the specified URL " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	/**
	 * Function to login into the application using valid credentials
	 * 
	 * @throws InterruptedException
	 * 
	 * @throws IOException
	 */
	protected static void login() throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			//byte[] encodedBytes = Base64.getEncoder().encode(properties.getProperty("EncodedPassword").getBytes());
			byte[] decodedBytes = Base64.getDecoder().decode(properties.getProperty("EncodedPassword").getBytes());
			//System.out.println("Encoded password ="+encodedBytes);
			//driver.switchTo().defaultContent();
			//driver.switchTo().frame("gsft_main");
			ReusableMethods.enterData(LoginPage.userName, properties.getProperty("Username"));
			ReusableMethods.enterData(LoginPage.password,new String(decodedBytes));
			ReusableMethods.click(LoginPage.login);
			test.log(LogStatus.PASS, "User able to login into the application Successfully", 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to login into the application Successfully " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void setImpersonateUser(String impersonateUser) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			ReusableMethods.waitUntilElementVisible(LoginPage.snGreetings);
			driver.get(properties.getProperty("ApplicationUrl"));
			ReusableMethods.click(LoginPage.userDropdown);
			ReusableMethods.clickJS(LoginPage.btnImpersonateUser);
			ReusableMethods.click(LoginPage.searchForUser);
			ReusableMethods.sendKeys(LoginPage.userSearchInputBox, impersonateUser);
			LoginPage.setImpersonateUser(impersonateUser);
			ReusableMethods.click(LoginPage.impersonateUser);
			ReusableMethods.waitUntilElementDisabled(LoginPage.dialogBoxImpersonateUser);
			driver.get(properties.getProperty("RedirectedApplicationUrl"));
			test.log(LogStatus.PASS, "User able to Impersonate as the User provided", 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to Impersonate as the User provided " + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void selectRelease(String release) throws IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			DetailedViewPage.setRelease(release);
			ReusableMethods.click(DetailedViewPage.projectRelease);
			ReusableMethods.waitUntilElementDisabled(DetailedViewPage.loading_dots);
			test.log(LogStatus.PASS, "User able to select the release provided", 
					test.addScreenCapture(capture(driver)));
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "User NOT able to select the release provided "  + e.getLocalizedMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}

	protected static void upcoming_milstones_validation(String user) throws InterruptedException, IOException {
		int index = 1;
		boolean flag = true;
		try {
			ReusableMethods.click(DashboardPage.upcoming_milestones);
			int milestones_size = ReusableMethods.getElementsSize(DashboardPage.GTM_milestones);
			if (milestones_size > 1) {
				for (; index<=1; index++) {
					ReusableMethods.click(DashboardPage.GTM_milestones + "[" + index + "]");
				}
			} else {
				ReusableMethods.click(DashboardPage.GTM_milestones + "[" + index + "]");
			}
			ReusableMethods.IsElementExists(DashboardPage.GTM_milestone_activities, flag, "Milestone Activities");
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			int milestone_activities_size = ReusableMethods.getElementsSize(DashboardPage.GTM_milestone_activities);
			int indexA = 1;
			if(milestone_activities_size>1) {
				for (; indexA<=1; indexA++) {
					ReusableMethods.click(DashboardPage.GTM_milestone_activities + "[" + indexA + "]");
				}
			} else {
				ReusableMethods.click(DashboardPage.GTM_milestone_activities + "[" + indexA + "]");
			}
			ReusableMethods.IsElementExists(DashboardPage.state_dropdown, flag, "Milestone State");
			ReusableMethods.IsElementExists(DashboardPage.milestonesubmit, flag, "Milestone Submit");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected static void addNewReleaseOla(DataTable releaseData) throws InterruptedException, IOException {
		WebDriver driver = DriverManager.getWebDriver();
		try {
			List<Map<String, String>> releases = releaseData.asMaps(String.class, String.class);
			int size = releases.size();
			for (int anchor = 0; anchor < size; anchor++) {
				Map<String,String> anchorData = releases.get(anchor);
				ReusableMethods.click(DashboardPage.add_release);
				ReusableMethods.enterData(DashboardPage.release_name,anchorData.get("ReleaseName"));
				ReusableMethods.enterData(DashboardPage.description,anchorData.get("Description"));
				ReusableMethods.clickWithoutScreenshot(DashboardPage.releasetype_dropdown);
				ReusableMethods.sendKeys(DashboardPage.releaseSearchInputBox, anchorData.get("ReleaseType"));
				DashboardPage.setReleaseType(anchorData.get("ReleaseType"));
				ReusableMethods.click(DashboardPage.releasetype);
				ReusableMethods.waitForLoad();
				try {
					if(driver.findElement(DashboardPage.submit).isDisplayed()) {
						System.out.println("Submit button is getting displayed ");
						test.log(LogStatus.PASS, "Submit button is getting displayed", 
								test.addScreenCapture(capture(driver)));
					}
				} catch(Exception e) {
					System.out.println("Submit button is NOT getting displayed ");
					test.log(LogStatus.FAIL, "Submit button is NOT getting displayed ", 
							test.addScreenCapture(capture(driver)));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.ERROR, "Submit button is NOT getting displayed " + e.getMessage(), 
					test.addScreenCapture(capture(driver)));
		}
	}
}