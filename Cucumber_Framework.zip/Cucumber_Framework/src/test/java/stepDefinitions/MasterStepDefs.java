package stepDefinitions;

import java.util.Properties;

import supportLibraries.ExtentReportClass;
import supportLibraries.SeleniumTestParameters;
import cucumber.api.Scenario;

public abstract class MasterStepDefs extends ExtentReportClass {

	protected static Scenario currentScenario;
	protected static SeleniumTestParameters currentTestParameters;
	protected static Properties propertiesFileAccess;
	
}