package testingSelenium;

import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.DetailedViewPage;
import supportLibraries.DriverManager;
import supportLibraries.ReusableMethods;
import supportLibraries.Settings;

public class testingPurpose {

	public static void main(String[] args) {
		WebDriver driver = null;
		try {
			Properties properties;
			properties = Settings.getInstance();

			System.setProperty("webdriver.chrome.driver", properties.getProperty("ChromeDriverPath"));

			driver = new ChromeDriver();
			driver.manage().window().maximize();

			driver.get(properties.getProperty("ApplicationUrl"));

			getDetailedViewColumnHeader(driver);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			driver.quit();
		}
	}

	protected static HashMap<String,String> getDetailedViewColumnHeader(WebDriver driver) {

		HashMap<String, String> columnData = new HashMap<String, String>();

		int headerColumnCount = driver.findElements((DetailedViewPage.columnHeaderDetailedView)).size();

		String getAriaHidden[] = new String[headerColumnCount-5];
		String getText[] = new String[headerColumnCount-5];

		for (int index = 0; index < (headerColumnCount - 5); index++) {
			getText[index] = driver.findElement(
					By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead/tr/th[" + (index + 5) + "]"))
					.getAttribute("textContent").trim();

			getAriaHidden[index] = driver.findElement(
					By.xpath("//*[@id='jsListView']/div[2]/div/div/div[4]/table/thead/tr/th[" + (index + 5) + "]"))
					.getAttribute("aria-hidden");

			columnData.put(getText[index], getAriaHidden[index]);
		}
		System.out.println(columnData);
		return columnData;
	}
}
