package tesngMaven;

import org.testng.annotations.Test;

public class TestNgMavenSecondClass {
	 @Test
	    public void oneMoreTest() {
	        System.out.println("This is a TestNG-Maven based test");
	    }
}
