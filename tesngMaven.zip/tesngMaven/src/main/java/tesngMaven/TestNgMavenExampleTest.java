package tesngMaven;

import org.testng.annotations.Test;

public class TestNgMavenExampleTest {
	 @Test
	    public void exampleOfTestNgMaven() {
	        System.out.println("This is TestNG-Maven Example");
	    }
	 @Test
	    public void abe() {
	        System.out.println("abe");
	    }
	 @Test(enabled = false)
	    public void testng2() {
	        System.out.println("Priority 1");
	    }
	 @Test(priority = 0)
	    public void testng4() {
	        System.out.println("Priority 2");
	    }
}
