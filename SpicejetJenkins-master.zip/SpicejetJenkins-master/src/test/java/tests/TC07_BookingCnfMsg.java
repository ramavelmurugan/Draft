package tests;

import org.testng.annotations.Test;

import base.ProjectSpecifications;

public class TC07_BookingCnfMsg extends ProjectSpecifications {

	@Test
	public void BookingConfirmMessage() {
		
		BookingCnfMsgPage bcm = new BookingCnfMsgPage();
	
		
	}
}
