package tests;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecifications;
import pages.Passenger_PaymentPage;
import pages.SelectFlightAndProceedToBookingPage;

public class TC06_Passenger_PaymentInfo extends ProjectSpecifications {

	@BeforeTest()
	public void setup() {
		sheetName = "PassengerPayDetails";
	}

	@Test(dataProvider = "getData")
	public void Passenger_Payment(String From, String To, String FN, String LN, String email, String Phone, String Town)
			throws IOException, InterruptedException {

		SelectFlightAndProceedToBookingPage sf = new SelectFlightAndProceedToBookingPage();
		sf.OneWayRadBtn();
		sf.From(From);
		sf.To(To);
		sf.DepatureDate();
		sf.SearchFlightBtn();
		Thread.sleep(7000);
		sf.ContinueBtn();

		Passenger_PaymentPage pp = new Passenger_PaymentPage();
		pp.PassengerDetails(FN, LN, email, Phone, Town);

	}
}
