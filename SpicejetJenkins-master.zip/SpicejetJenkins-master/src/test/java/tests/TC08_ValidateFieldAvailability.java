package tests;//check-in, flight status, manage bookings

import org.testng.annotations.Test;

import base.ProjectSpecifications;

public class TC08_ValidateFieldAvailability extends ProjectSpecifications {
	
	@Test
public void ValidateField() {
	
		
		
}
}
