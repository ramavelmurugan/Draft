package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecifications;

public class Passenger_PaymentPage extends ProjectSpecifications{	
	
	@FindBy(xpath="//input[@data-testid='first-inputbox-contact-details']")
	WebElement firstname;
	
	@FindBy(xpath="//input[@data-testid='last-inputbox-contact-details']")
	WebElement lastname;
	
	@FindBy(xpath="//input[@data-testid='contact-number-input-box']")
	WebElement phone;
	
	@FindBy(xpath="//input[@data-testid='emailAddress-inputbox-contact-details']")
	WebElement email;
	
	@FindBy(xpath="(//div[text()='I am flying as the primary passenger']/..//div)[1]")
	WebElement checkbox;
			
	@FindBy(xpath="//div[@data-testid='traveller-info-continue-cta']")
	WebElement Continue_1;
	
	@FindBy(xpath="(//div[@data-testid='add-ons-continue-footer-button'])[3]")
	WebElement Continue;
	
	@FindBy(xpath="//input[@data-testid='city-inputbox-contact-details']")
	WebElement town;
	
	@FindBy(xpath="//div[@data-testid='common-proceed-to-pay']")
	WebElement proceed_payment;
	
	@FindBy(xpath="//div[text()='Invalid Card Details']")
	WebElement errormsg;
	
	@FindBy(xpath="//div[@id='at_addon_close_icon']")
	WebElement close;
	
	public Passenger_PaymentPage() {
		PageFactory.initElements(driver, this);
	}

	
	public void PassengerDetails(String FN, String LN, String email_val, String Phone, String Town ) throws InterruptedException {
		sendKeys(firstname, FN);
		sendKeys(lastname, LN);
		sendKeys(phone, Phone);
		sendKeys(email, email_val);
		sendKeys(town, Town);
		click(checkbox);
		Thread.sleep(3000);
		click(Continue_1);	
		Thread.sleep(3000);
		click(close);
		Thread.sleep(3000);
		click(Continue);
		Thread.sleep(3000);
		click(Continue);
		Thread.sleep(3000);
		click(proceed_payment);
		
		String actual=errormsg.getText();
		assertEquals("Invalid Card Details",actual);
	}
	
}
